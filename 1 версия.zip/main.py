#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DATABASE SEARCH TOOL v2.0
Search in TXT/CSV databases
"""

import os
import sys

# Fix path - get directory where main.py is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)
sys.path.insert(0, SCRIPT_DIR)

# Now import modules
try:
    from modules.search_engine import SearchEngine
    from modules.ui_manager import UIManager
    from modules.config_manager import ConfigManager
    from modules.logger import Logger
    from modules.file_indexer import FileIndexer
    from modules.result_exporter import ResultExporter
    from modules.stats_manager import StatsManager
    from modules.cache_manager import CacheManager
    from modules.parallel_processor import ParallelProcessor
    from modules.database_manager import DatabaseManager
except ImportError as e:
    print(f"[ERROR] Cannot import module: {e}")
    print(f"[INFO] Script directory: {SCRIPT_DIR}")
    print(f"[INFO] Checking modules folder...")
    
    modules_path = os.path.join(SCRIPT_DIR, 'modules')
    if os.path.exists(modules_path):
        print(f"[OK] Modules folder exists")
        print(f"[INFO] Files in modules: {os.listdir(modules_path)}")
    else:
        print(f"[ERROR] Modules folder not found!")
        print(f"[INFO] Please make sure 'modules' folder exists")
    
    input("\nPress Enter to exit...")
    sys.exit(1)

def main():
    """Main function"""
    try:
        # Initialize components
        config = ConfigManager()
        logger = Logger(config)
        ui = UIManager(config)
        
        # Clear screen and show banner
        ui.clear_screen()
        ui.show_banner()
        
        # Initialize managers
        cache = CacheManager(config)
        db_manager = DatabaseManager(config, logger)
        indexer = FileIndexer(config, logger)
        processor = ParallelProcessor(config, logger)
        exporter = ResultExporter(config, logger)
        stats = StatsManager(config, logger)
        
        # Create search engine
        search_engine = SearchEngine(
            config=config,
            logger=logger,
            cache=cache,
            indexer=indexer,
            processor=processor,
            db_manager=db_manager
        )
        
        # Main loop
        while True:
            ui.show_menu()
            choice = ui.get_user_choice()
            
            if choice == '1':
                # Search in databases
                ui.clear_screen()
                ui.show_search_header()
                query = ui.get_search_query()
                
                if query:
                    ui.show_progress_start()
                    results = search_engine.search(query)
                    ui.show_results(results, stats)
                    
                    if results and ui.ask_export():
                        exporter.export(results, query)
                        ui.show_export_success()
                        
            elif choice == '2':
                # Index databases
                ui.clear_screen()
                ui.show_indexing_header()
                indexer.index_all_databases()
                ui.show_indexing_complete(indexer.get_stats())
                
            elif choice == '3':
                # Statistics
                ui.clear_screen()
                stats.show_statistics()
                
            elif choice == '4':
                # Settings
                ui.clear_screen()
                config.interactive_settings(ui)
                
            elif choice == '5':
                # Clear cache
                cache.clear()
                ui.show_cache_cleared()
                
            elif choice == '6':
                # Database info
                ui.clear_screen()
                db_manager.show_database_info()
                
            elif choice == '0' or choice.lower() == 'q':
                ui.show_goodbye()
                break
            else:
                ui.show_invalid_choice()
                
            ui.wait_for_key()
            
    except KeyboardInterrupt:
        print("\n\n[!] Program interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n[ERROR] Critical error: {e}")
        import traceback
        traceback.print_exc()
        input("\nPress Enter to exit...")
        sys.exit(1)

if __name__ == "__main__":
    main()
