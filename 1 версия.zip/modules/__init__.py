# -*- coding: utf-8 -*-
"""
Модули для Database Search Tool
"""

__version__ = "2.0.0"
__author__ = "DB Search Tool"