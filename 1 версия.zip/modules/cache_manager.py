# -*- coding: utf-8 -*-
"""
Менеджер кэширования
"""

import os
import json
import time
import hashlib
from typing import Any, Optional, Dict, List

class CacheManager:
    """Кэширование результатов поиска"""
    
    def __init__(self, config):
        self.config = config
        self.cache_path = config.get('cache_path', 'cache')
        self.cache_enabled = config.get('cache_enabled', True)
        self.cache_ttl = config.get('cache_ttl', 3600)  # 1 час
        self.cache = {}
        
        os.makedirs(self.cache_path, exist_ok=True)
        self._load_cache()
    
    def _get_cache_file(self) -> str:
        """Путь к файлу кэша"""
        return os.path.join(self.cache_path, 'search_cache.json')
    
    def _load_cache(self):
        """Загрузка кэша из файла"""
        cache_file = self._get_cache_file()
        
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    self.cache = json.load(f)
                
                # Очистка устаревших записей
                self._cleanup_expired()
            except:
                self.cache = {}
    
    def _save_cache(self):
        """Сохранение кэша в файл"""
        try:
            with open(self._get_cache_file(), 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, ensure_ascii=False)
        except:
            pass
    
    def _get_key(self, query: str) -> str:
        """Генерация ключа кэша"""
        return hashlib.md5(query.lower().encode()).hexdigest()
    
    def get(self, query: str) -> Optional[List[Dict]]:
        """Получение из кэша"""
        if not self.cache_enabled:
            return None
        
        key = self._get_key(query)
        
        if key in self.cache:
            entry = self.cache[key]
            
            # Проверка времени жизни
            if time.time() - entry.get('timestamp', 0) < self.cache_ttl:
                return entry.get('data')
            else:
                # Устарело
                del self.cache[key]
        
        return None
    
    def set(self, query: str, data: List[Dict]):
        """Сохранение в кэш"""
        if not self.cache_enabled:
            return
        
        key = self._get_key(query)
        
        self.cache[key] = {
            'query': query,
            'data': data[:1000],  # Ограничение размера
            'timestamp': time.time()
        }
        
        self._save_cache()
    
    def _cleanup_expired(self):
        """Очистка устаревших записей"""
        current_time = time.time()
        expired_keys = [
            key for key, entry in self.cache.items()
            if current_time - entry.get('timestamp', 0) >= self.cache_ttl
        ]
        
        for key in expired_keys:
            del self.cache[key]
        
        if expired_keys:
            self._save_cache()
    
    def clear(self):
        """Полная очистка кэша"""
        self.cache = {}
        
        cache_file = self._get_cache_file()
        if os.path.exists(cache_file):
            os.remove(cache_file)
        
        # Очистка других файлов кэша
        for f in os.listdir(self.cache_path):
            filepath = os.path.join(self.cache_path, f)
            try:
                if os.path.isfile(filepath):
                    os.remove(filepath)
            except:
                pass
    
    def get_size(self) -> int:
        """Размер кэша"""
        return len(self.cache)
