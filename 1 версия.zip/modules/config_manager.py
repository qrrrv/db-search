# -*- coding: utf-8 -*-
"""
Configuration Manager
"""

import os
import json
from typing import Any, Dict, Optional

class ConfigManager:
    """Program settings manager"""
    
    DEFAULT_CONFIG = {
        'database_path': 'bd',
        'results_path': 'results',
        'cache_path': 'cache',
        'logs_path': 'logs',
        'file_extensions': ['.txt', '.csv'],
        'max_workers': None,
        'max_results_per_file': 1000,
        'max_total_results': 10000,
        'cache_enabled': True,
        'cache_ttl': 3600,
        'encoding_priority': ['utf-8', 'cp1251', 'latin-1', 'cp866'],
        'use_mmap_threshold': 104857600,
        'chunk_size': 1048576,
        'show_progress': True,
        'color_output': True,
        'log_level': 'INFO',
        'export_format': 'txt',
    }
    
    def __init__(self, config_file: str = 'config.json'):
        self.config_file = config_file
        self.config = self.DEFAULT_CONFIG.copy()
        self._load_config()
        self._ensure_directories()
    
    def _load_config(self):
        """Load configuration from file"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    self.config.update(loaded)
            except Exception as e:
                print(f"[!] Config load error: {e}")
        else:
            self._save_config()
    
    def _save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"[!] Config save error: {e}")
    
    def _ensure_directories(self):
        """Create necessary directories"""
        dirs = [
            self.config['database_path'],
            self.config['results_path'],
            self.config['cache_path'],
            self.config['logs_path'],
        ]
        for d in dirs:
            os.makedirs(d, exist_ok=True)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        return self.config.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set configuration value"""
        self.config[key] = value
        self._save_config()
    
    def get_all(self) -> Dict:
        """Get all configuration"""
        return self.config.copy()
    
    def interactive_settings(self, ui):
        """Interactive settings menu"""
        print("\n=== SETTINGS ===\n")
        print("Current settings:")
        print(f"  1. Database path: {self.config['database_path']}")
        print(f"  2. Results path: {self.config['results_path']}")
        print(f"  3. Max workers: {self.config['max_workers'] or 'Auto'}")
        print(f"  4. Cache: {'On' if self.config['cache_enabled'] else 'Off'}")
        print(f"  5. Export format: {self.config['export_format']}")
        print(f"  0. Back\n")
        
        choice = input("Select setting to change: ").strip()
        
        if choice == '1':
            new_path = input("New database path: ").strip()
            if new_path:
                self.set('database_path', new_path)
                print("[OK] Path updated")
        elif choice == '2':
            new_path = input("New results path: ").strip()
            if new_path:
                self.set('results_path', new_path)
                print("[OK] Path updated")
        elif choice == '3':
            workers = input("Number of threads (Enter for auto): ").strip()
            self.set('max_workers', int(workers) if workers else None)
            print("[OK] Setting updated")
        elif choice == '4':
            self.set('cache_enabled', not self.config['cache_enabled'])
            print(f"[OK] Cache: {'On' if self.config['cache_enabled'] else 'Off'}")
        elif choice == '5':
            fmt = input("Format (txt/csv/json): ").strip().lower()
            if fmt in ['txt', 'csv', 'json']:
                self.set('export_format', fmt)
                print("[OK] Format updated")
