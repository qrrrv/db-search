# -*- coding: utf-8 -*-
"""
File Indexer for databases
"""

import os
import time
import json
from typing import Dict, List, Any
from concurrent.futures import ThreadPoolExecutor
import multiprocessing

class FileIndexer:
    """Indexer for fast search in large databases"""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.index = {}
        self.stats = {
            'files': 0,
            'records': 0,
            'time': 0
        }
        self.index_file = os.path.join(config.get('cache_path', 'cache'), 'index.json')
        self._load_index()
    
    def _load_index(self):
        """Load existing index"""
        if os.path.exists(self.index_file):
            try:
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    self.index = json.load(f)
                self.logger.info(f"Index loaded: {len(self.index)} files")
            except Exception as e:
                self.logger.error(f"Error loading index: {e}")
                self.index = {}
    
    def _save_index(self):
        """Save index"""
        try:
            with open(self.index_file, 'w', encoding='utf-8') as f:
                json.dump(self.index, f, ensure_ascii=False, indent=2)
            self.logger.info("Index saved")
        except Exception as e:
            self.logger.error(f"Error saving index: {e}")
    
    def index_all_databases(self):
        """Index all databases"""
        start_time = time.time()
        db_path = self.config.get('database_path', 'bd')
        
        if not os.path.exists(db_path):
            os.makedirs(db_path, exist_ok=True)
            self.logger.warning(f"Created empty directory: {db_path}")
            return
        
        files = self._get_all_files(db_path)
        self.stats['files'] = len(files)
        
        print(f"[*] Found files for indexing: {len(files)}")
        
        max_workers = self.config.get('max_workers') or multiprocessing.cpu_count()
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            results = list(executor.map(self._index_file, files))
        
        self.stats['records'] = sum(results)
        self.stats['time'] = time.time() - start_time
        
        self._save_index()
        
        self.logger.info(
            f"Indexing complete: {self.stats['files']} files, "
            f"{self.stats['records']} records in {self.stats['time']:.2f} sec"
        )
    
    def _get_all_files(self, path: str) -> List[str]:
        """Get list of all files"""
        files = []
        extensions = self.config.get('file_extensions', ['.txt', '.csv'])
        
        for root, dirs, filenames in os.walk(path):
            for filename in filenames:
                if any(filename.lower().endswith(ext) for ext in extensions):
                    files.append(os.path.join(root, filename))
        
        return files
    
    def _index_file(self, file_path: str) -> int:
        """Index single file"""
        try:
            file_hash = self._get_file_hash(file_path)
            
            if file_path in self.index:
                if self.index[file_path].get('hash') == file_hash:
                    return self.index[file_path].get('lines', 0)
            
            lines = 0
            file_size = os.path.getsize(file_path)
            
            encodings = self.config.get('encoding_priority', ['utf-8', 'cp1251'])
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                        lines = sum(1 for _ in f)
                    break
                except:
                    continue
            
            self.index[file_path] = {
                'hash': file_hash,
                'lines': lines,
                'size': file_size,
                'name': os.path.basename(file_path)
            }
            
            return lines
            
        except Exception as e:
            self.logger.error(f"Error indexing {file_path}: {e}")
            return 0
    
    def _get_file_hash(self, file_path: str) -> str:
        """Get file hash (fast method)"""
        try:
            stat = os.stat(file_path)
            return f"{stat.st_size}_{stat.st_mtime}"
        except:
            return ""
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics"""
        return self.stats.copy()
    
    def is_file_indexed(self, file_path: str) -> bool:
        """Check if file is indexed"""
        return file_path in self.index
