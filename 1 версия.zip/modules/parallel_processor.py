# -*- coding: utf-8 -*-
"""
Параллельный процессор для обработки больших файлов
"""

import os
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from typing import List, Callable, Any, Generator
import mmap

class ParallelProcessor:
    """Параллельная обработка файлов с использованием всех ядер CPU"""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.max_workers = config.get('max_workers') or multiprocessing.cpu_count()
        self.chunk_size = config.get('chunk_size', 1024 * 1024)  # 1MB
    
    def get_cpu_count(self) -> int:
        """Получение количества CPU"""
        return multiprocessing.cpu_count()
    
    def process_files_parallel(self, files: List[str], processor_func: Callable) -> List[Any]:
        """Параллельная обработка списка файлов"""
        results = []
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(processor_func, f): f for f in files}
            
            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result:
                        results.extend(result) if isinstance(result, list) else results.append(result)
                except Exception as e:
                    self.logger.error(f"Ошибка обработки: {e}")
        
        return results
    
    def read_file_chunks(self, file_path: str) -> Generator[bytes, None, None]:
        """Чтение файла по частям"""
        try:
            with open(file_path, 'rb') as f:
                while True:
                    chunk = f.read(self.chunk_size)
                    if not chunk:
                        break
                    yield chunk
        except Exception as e:
            self.logger.error(f"Ошибка чтения {file_path}: {e}")
    
    def read_large_file_mmap(self, file_path: str) -> Generator[str, None, None]:
        """Чтение большого файла через memory mapping"""
        try:
            with open(file_path, 'rb') as f:
                with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                    for line in iter(mm.readline, b''):
                        yield line.decode('utf-8', errors='ignore')
        except Exception as e:
            self.logger.error(f"MMAP ошибка {file_path}: {e}")
    
    def estimate_processing_time(self, total_size_bytes: int) -> float:
        """Оценка времени обработки"""
        # Примерная скорость: 100 MB/сек на одно ядро
        speed_per_core = 100 * 1024 * 1024  # bytes/sec
        total_speed = speed_per_core * self.max_workers
        return total_size_bytes / total_speed
