# -*- coding: utf-8 -*-
"""
Поисковый движок - ядро программы
"""

import os
import re
import csv
import mmap
import threading
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from typing import List, Dict, Any, Optional, Generator
import multiprocessing

class SearchEngine:
    """Мощный поисковый движок для больших баз данных"""
    
    def __init__(self, config, logger, cache, indexer, processor, db_manager):
        self.config = config
        self.logger = logger
        self.cache = cache
        self.indexer = indexer
        self.processor = processor
        self.db_manager = db_manager
        self.results = []
        self.total_lines_searched = 0
        self.files_searched = 0
        
    def search(self, query: str) -> List[Dict[str, Any]]:
        """Главный метод поиска"""
        self.results = []
        self.total_lines_searched = 0
        self.files_searched = 0
        
        # Проверяем кэш
        cached = self.cache.get(query)
        if cached:
            self.logger.info(f"Результаты из кэша для: {query}")
            return cached
        
        # Получаем список файлов для поиска
        db_path = self.config.get('database_path', 'бд')
        files = self._get_database_files(db_path)
        
        if not files:
            self.logger.warning("Файлы баз данных не найдены!")
            return []
        
        self.logger.info(f"Найдено {len(files)} файлов для поиска")
        
        # Параллельный поиск
        max_workers = self.config.get('max_workers', multiprocessing.cpu_count())
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(self._search_file, file_path, query): file_path 
                for file_path in files
            }
            
            for future in as_completed(futures):
                file_path = futures[future]
                try:
                    file_results = future.result()
                    self.results.extend(file_results)
                    self.files_searched += 1
                except Exception as e:
                    self.logger.error(f"Ошибка при поиске в {file_path}: {e}")
        
        # Сохраняем в кэш
        if self.results:
            self.cache.set(query, self.results)
        
        self.logger.info(f"Поиск завершён. Найдено: {len(self.results)} результатов")
        return self.results
    
    def _get_database_files(self, path: str) -> List[str]:
        """Получение списка файлов баз данных"""
        files = []
        extensions = self.config.get('file_extensions', ['.txt', '.csv'])
        
        if not os.path.exists(path):
            os.makedirs(path, exist_ok=True)
            return files
        
        for root, dirs, filenames in os.walk(path):
            for filename in filenames:
                if any(filename.lower().endswith(ext) for ext in extensions):
                    files.append(os.path.join(root, filename))
        
        return files
    
    def _search_file(self, file_path: str, query: str) -> List[Dict[str, Any]]:
        """Поиск в одном файле"""
        results = []
        query_lower = query.lower()
        query_bytes = query.lower().encode('utf-8', errors='ignore')
        
        try:
            file_size = os.path.getsize(file_path)
            
            # Для больших файлов используем mmap
            if file_size > 100 * 1024 * 1024:  # > 100MB
                results = self._search_file_mmap(file_path, query_bytes, query_lower)
            else:
                results = self._search_file_standard(file_path, query_lower)
                
        except Exception as e:
            self.logger.error(f"Ошибка чтения {file_path}: {e}")
        
        return results
    
    def _search_file_mmap(self, file_path: str, query_bytes: bytes, query_str: str) -> List[Dict[str, Any]]:
        """Поиск с использованием memory-mapped файлов (для больших файлов)"""
        results = []
        
        try:
            with open(file_path, 'rb') as f:
                with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                    line_num = 0
                    start = 0
                    
                    while True:
                        line_end = mm.find(b'\n', start)
                        if line_end == -1:
                            line = mm[start:]
                            if query_bytes in line.lower():
                                results.append(self._create_result(
                                    file_path, line_num, 
                                    line.decode('utf-8', errors='ignore').strip()
                                ))
                            break
                        
                        line = mm[start:line_end]
                        line_num += 1
                        self.total_lines_searched += 1
                        
                        if query_bytes in line.lower():
                            results.append(self._create_result(
                                file_path, line_num,
                                line.decode('utf-8', errors='ignore').strip()
                            ))
                        
                        start = line_end + 1
                        
                        # Ограничение результатов
                        if len(results) >= self.config.get('max_results_per_file', 1000):
                            break
                            
        except Exception as e:
            self.logger.error(f"MMAP ошибка в {file_path}: {e}")
        
        return results
    
    def _search_file_standard(self, file_path: str, query: str) -> List[Dict[str, Any]]:
        """Стандартный построчный поиск"""
        results = []
        encodings = ['utf-8', 'cp1251', 'latin-1', 'cp866']
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                    for line_num, line in enumerate(f, 1):
                        self.total_lines_searched += 1
                        
                        if query in line.lower():
                            results.append(self._create_result(file_path, line_num, line.strip()))
                            
                            if len(results) >= self.config.get('max_results_per_file', 1000):
                                break
                break
            except UnicodeDecodeError:
                continue
            except Exception as e:
                self.logger.error(f"Ошибка чтения {file_path} ({encoding}): {e}")
                break
        
        return results
    
    def _create_result(self, file_path: str, line_num: int, line: str) -> Dict[str, Any]:
        """Создание результата поиска"""
        # Парсинг данных из строки
        parsed_data = self._parse_line(line, file_path)
        
        return {
            'file': os.path.basename(file_path),
            'file_path': file_path,
            'line_number': line_num,
            'raw_data': line,
            'parsed': parsed_data
        }
    
    def _parse_line(self, line: str, file_path: str) -> Dict[str, Any]:
        """Парсинг строки данных"""
        parsed = {}
        
        # Определяем разделитель
        if file_path.endswith('.csv'):
            parts = line.split(',')
        elif ':' in line:
            parts = line.split(':')
        elif ';' in line:
            parts = line.split(';')
        elif '\t' in line:
            parts = line.split('\t')
        elif '|' in line:
            parts = line.split('|')
        else:
            parts = line.split()
        
        # Пытаемся извлечь известные поля
        for i, part in enumerate(parts):
            part = part.strip()
            
            # Telegram ID
            if re.match(r'^\d{6,12}$', part):
                if 'telegram_id' not in parsed:
                    parsed['telegram_id'] = part
            
            # Телефон
            elif re.match(r'^[\+]?[\d\s\-\(\)]{10,15}$', part):
                if 'phone' not in parsed:
                    parsed['phone'] = part
            
            # Email
            elif re.match(r'^[\w\.\-]+@[\w\.\-]+\.\w+$', part):
                if 'email' not in parsed:
                    parsed['email'] = part
            
            # Username (@username)
            elif part.startswith('@'):
                if 'username' not in parsed:
                    parsed['username'] = part
            
            # Возможно имя (кириллица или латиница)
            elif re.match(r'^[А-Яа-яЁёA-Za-z]{2,}$', part):
                if 'name' not in parsed:
                    parsed['name'] = part
                elif 'surname' not in parsed:
                    parsed['surname'] = part
        
        return parsed
    
    def get_statistics(self) -> Dict[str, Any]:
        """Получение статистики поиска"""
        return {
            'total_results': len(self.results),
            'files_searched': self.files_searched,
            'lines_searched': self.total_lines_searched
        }
