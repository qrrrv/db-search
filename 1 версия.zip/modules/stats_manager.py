# -*- coding: utf-8 -*-
"""
Statistics Manager
"""

import os
import json
from datetime import datetime
from typing import Dict, Any

class StatsManager:
    """Statistics collection and display"""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.stats_file = os.path.join(config.get('cache_path', 'cache'), 'stats.json')
        self.stats = self._load_stats()
    
    def _load_stats(self) -> Dict:
        """Load statistics"""
        if os.path.exists(self.stats_file):
            try:
                with open(self.stats_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            'total_searches': 0,
            'total_results_found': 0,
            'searches_history': [],
            'last_search': None,
            'databases_info': {}
        }
    
    def _save_stats(self):
        """Save statistics"""
        try:
            with open(self.stats_file, 'w', encoding='utf-8') as f:
                json.dump(self.stats, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving statistics: {e}")
    
    def record_search(self, query: str, results_count: int, duration: float):
        """Record search in statistics"""
        self.stats['total_searches'] += 1
        self.stats['total_results_found'] += results_count
        self.stats['last_search'] = {
            'query': query,
            'results': results_count,
            'duration': duration,
            'timestamp': datetime.now().isoformat()
        }
        
        self.stats['searches_history'].append(self.stats['last_search'])
        self.stats['searches_history'] = self.stats['searches_history'][-100:]
        
        self._save_stats()
    
    def show_statistics(self):
        """Show statistics"""
        db_path = self.config.get('database_path', 'bd')
        
        total_files = 0
        total_size = 0
        
        if os.path.exists(db_path):
            for root, dirs, files in os.walk(db_path):
                for f in files:
                    if f.endswith(('.txt', '.csv')):
                        total_files += 1
                        try:
                            total_size += os.path.getsize(os.path.join(root, f))
                        except:
                            pass
        
        size_gb = total_size / (1024 ** 3)
        size_mb = total_size / (1024 ** 2)
        
        print("\n" + "=" * 60)
        print("                    STATISTICS")
        print("=" * 60)
        print(f"\n  Databases:")
        print(f"     Files: {total_files}")
        print(f"     Size: {size_gb:.2f} GB ({size_mb:.0f} MB)")
        print(f"     Path: {db_path}")
        
        print(f"\n  Searches:")
        print(f"     Total searches: {self.stats['total_searches']}")
        print(f"     Results found: {self.stats['total_results_found']}")
        
        if self.stats['last_search']:
            last = self.stats['last_search']
            print(f"\n  Last search:")
            print(f"     Query: {last['query']}")
            print(f"     Results: {last['results']}")
            print(f"     Time: {last['duration']:.2f} sec")
        
        print("\n" + "=" * 60)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics"""
        return self.stats.copy()
