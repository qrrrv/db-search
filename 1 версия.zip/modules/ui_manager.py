# -*- coding: utf-8 -*-
"""
User Interface Manager
Beautiful console UI with colors and animations
"""

import os
import sys
import time
from typing import List, Dict, Any, Optional

# Try to import libraries for beautiful interface
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.box import ROUNDED, DOUBLE
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

try:
    from colorama import init, Fore, Back, Style as ColoramaStyle
    init(autoreset=True)
    COLORAMA_AVAILABLE = True
except ImportError:
    COLORAMA_AVAILABLE = False

try:
    from pyfiglet import Figlet
    PYFIGLET_AVAILABLE = True
except ImportError:
    PYFIGLET_AVAILABLE = False

try:
    from tabulate import tabulate
    TABULATE_AVAILABLE = True
except ImportError:
    TABULATE_AVAILABLE = False

try:
    from prompt_toolkit import prompt
    from prompt_toolkit.formatted_text import HTML
    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:
    PROMPT_TOOLKIT_AVAILABLE = False


class UIManager:
    """Beautiful console interface manager"""
    
    COLORS = {
        'RED': '\033[91m',
        'GREEN': '\033[92m',
        'YELLOW': '\033[93m',
        'BLUE': '\033[94m',
        'MAGENTA': '\033[95m',
        'CYAN': '\033[96m',
        'WHITE': '\033[97m',
        'RESET': '\033[0m',
        'BOLD': '\033[1m',
        'DIM': '\033[2m',
    }
    
    def __init__(self, config):
        self.config = config
        
        if RICH_AVAILABLE:
            self.console = Console()
        else:
            self.console = None
    
    def clear_screen(self):
        """Clear screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def show_banner(self):
        """Show beautiful banner"""
        if PYFIGLET_AVAILABLE and RICH_AVAILABLE:
            try:
                fig = Figlet(font='slant')
                banner_text = fig.renderText('DB SEARCH')
                self.console.print(Panel(
                    Text(banner_text, style="bold cyan"),
                    border_style="blue",
                    box=DOUBLE,
                    title="[bold yellow]v2.0[/bold yellow]",
                    subtitle="[dim]Database Search Tool[/dim]"
                ))
            except:
                self._print_simple_banner()
        elif RICH_AVAILABLE:
            self.console.print(Panel(
                "[bold cyan]========================================\n"
                "       DATABASE SEARCH TOOL v2.0\n"
                "     Search in TXT/CSV databases\n"
                "========================================[/bold cyan]",
                border_style="blue"
            ))
        else:
            self._print_simple_banner()
    
    def _print_simple_banner(self):
        """Simple banner without libraries"""
        c = self.COLORS
        print(f"""
{c['CYAN']}{c['BOLD']}================================================================
          DATABASE SEARCH TOOL v2.0
          Search in TXT/CSV databases
          Optimized for large files (20-70 GB)
================================================================{c['RESET']}
""")
    
    def show_menu(self):
        """Show main menu"""
        if RICH_AVAILABLE:
            menu_content = """
[bold cyan]========================================
           [yellow]MAIN MENU[/yellow]
========================================

  [green][1][/green] Search in databases
  [green][2][/green] Index databases
  [green][3][/green] Statistics
  [green][4][/green] Settings
  [green][5][/green] Clear cache
  [green][6][/green] Database info
  [red][0][/red] Exit

========================================[/bold cyan]
"""
            self.console.print(Panel(menu_content, border_style="blue"))
        else:
            c = self.COLORS
            print(f"""
{c['CYAN']}========================================
           {c['YELLOW']}MAIN MENU{c['CYAN']}
========================================

  {c['GREEN']}[1]{c['CYAN']} Search in databases
  {c['GREEN']}[2]{c['CYAN']} Index databases
  {c['GREEN']}[3]{c['CYAN']} Statistics
  {c['GREEN']}[4]{c['CYAN']} Settings
  {c['GREEN']}[5]{c['CYAN']} Clear cache
  {c['GREEN']}[6]{c['CYAN']} Database info
  {c['RED']}[0]{c['CYAN']} Exit

========================================{c['RESET']}
""")
    
    def get_user_choice(self) -> str:
        """Get user choice"""
        if PROMPT_TOOLKIT_AVAILABLE:
            try:
                return prompt(HTML('<cyan><b>Select action: </b></cyan>'))
            except:
                pass
        return input(f"{self.COLORS['CYAN']}> Select action: {self.COLORS['RESET']}")
    
    def get_search_query(self) -> str:
        """Get search query"""
        if RICH_AVAILABLE:
            self.console.print("\n[bold yellow]Enter search query:[/bold yellow]")
            self.console.print("[dim](Telegram ID, phone, name, email, username)[/dim]\n")
        else:
            print(f"\n{self.COLORS['YELLOW']}Enter search query:{self.COLORS['RESET']}")
            print(f"{self.COLORS['DIM']}(Telegram ID, phone, name, email, username){self.COLORS['RESET']}\n")
        
        if PROMPT_TOOLKIT_AVAILABLE:
            try:
                return prompt(HTML('<green><b>Search: </b></green>'))
            except:
                pass
        return input(f"{self.COLORS['GREEN']}Search: {self.COLORS['RESET']}")
    
    def show_search_header(self):
        """Search header"""
        if RICH_AVAILABLE:
            self.console.print(Panel(
                "[bold cyan]SEARCH IN DATABASES[/bold cyan]",
                border_style="cyan"
            ))
        else:
            print(f"\n{self.COLORS['CYAN']}{'='*50}")
            print(f"       SEARCH IN DATABASES")
            print(f"{'='*50}{self.COLORS['RESET']}\n")
    
    def show_progress_start(self):
        """Show progress start"""
        if RICH_AVAILABLE:
            self.console.print("\n[bold yellow]Searching...[/bold yellow]\n")
        else:
            print(f"\n{self.COLORS['YELLOW']}Searching...{self.COLORS['RESET']}\n")
    
    def show_results(self, results: List[Dict], stats=None):
        """Show search results"""
        if not results:
            if RICH_AVAILABLE:
                self.console.print(Panel(
                    "[bold red]Nothing found[/bold red]",
                    border_style="red"
                ))
            else:
                print(f"\n{self.COLORS['RED']}Nothing found{self.COLORS['RESET']}\n")
            return
        
        if RICH_AVAILABLE:
            self.console.print(f"\n[bold green]Found: {len(results)} results[/bold green]\n")
            
            table = Table(
                title="Search Results",
                box=ROUNDED,
                border_style="cyan",
                header_style="bold magenta"
            )
            
            table.add_column("#", style="dim", width=4)
            table.add_column("File", style="cyan", width=20)
            table.add_column("Line", style="yellow", width=8)
            table.add_column("Data", style="green", max_width=60)
            
            for i, result in enumerate(results[:50], 1):
                parsed = result.get('parsed', {})
                parsed_str = " | ".join([f"{k}: {v}" for k, v in parsed.items()])
                
                table.add_row(
                    str(i),
                    result.get('file', 'N/A')[:20],
                    str(result.get('line_number', 'N/A')),
                    parsed_str or result.get('raw_data', '')[:60]
                )
            
            self.console.print(table)
            
            if len(results) > 50:
                self.console.print(f"\n[dim]... and {len(results) - 50} more results[/dim]")
        
        elif TABULATE_AVAILABLE:
            print(f"\n{self.COLORS['GREEN']}Found: {len(results)} results{self.COLORS['RESET']}\n")
            
            table_data = []
            for i, result in enumerate(results[:50], 1):
                parsed = result.get('parsed', {})
                parsed_str = " | ".join([f"{k}: {v}" for k, v in parsed.items()])
                table_data.append([
                    i,
                    result.get('file', 'N/A')[:20],
                    result.get('line_number', 'N/A'),
                    (parsed_str or result.get('raw_data', ''))[:60]
                ])
            
            print(tabulate(table_data, headers=['#', 'File', 'Line', 'Data'], tablefmt='grid'))
        
        else:
            print(f"\n{self.COLORS['GREEN']}Found: {len(results)} results{self.COLORS['RESET']}\n")
            print(f"{'-'*80}")
            
            for i, result in enumerate(results[:50], 1):
                print(f"{self.COLORS['CYAN']}[{i}]{self.COLORS['RESET']} {result.get('file', 'N/A')} "
                      f"(line {result.get('line_number', 'N/A')})")
                print(f"    {self.COLORS['GREEN']}{result.get('raw_data', '')[:80]}{self.COLORS['RESET']}")
                print(f"{'-'*80}")
    
    def show_indexing_header(self):
        """Indexing header"""
        if RICH_AVAILABLE:
            self.console.print(Panel(
                "[bold cyan]INDEXING DATABASES[/bold cyan]",
                border_style="cyan"
            ))
        else:
            print(f"\n{self.COLORS['CYAN']}{'='*50}")
            print(f"       INDEXING DATABASES")
            print(f"{'='*50}{self.COLORS['RESET']}\n")
    
    def show_indexing_complete(self, stats: Dict):
        """Show indexing complete"""
        if RICH_AVAILABLE:
            self.console.print(Panel(
                f"[bold green]Indexing complete![/bold green]\n\n"
                f"Files indexed: {stats.get('files', 0)}\n"
                f"Records processed: {stats.get('records', 0)}\n"
                f"Time: {stats.get('time', 0):.2f} sec",
                border_style="green"
            ))
        else:
            c = self.COLORS
            print(f"\n{c['GREEN']}Indexing complete!")
            print(f"   Files: {stats.get('files', 0)}")
            print(f"   Records: {stats.get('records', 0)}")
            print(f"   Time: {stats.get('time', 0):.2f} sec{c['RESET']}")
    
    def ask_export(self) -> bool:
        """Ask about export"""
        if RICH_AVAILABLE:
            self.console.print("\n[yellow]Export results? (y/n)[/yellow]")
        else:
            print(f"\n{self.COLORS['YELLOW']}Export results? (y/n){self.COLORS['RESET']}")
        
        choice = input("> ").strip().lower()
        return choice in ['y', 'yes']
    
    def show_export_success(self):
        """Export success"""
        if RICH_AVAILABLE:
            self.console.print("[bold green]Results exported to 'results' folder[/bold green]")
        else:
            print(f"{self.COLORS['GREEN']}Results exported to 'results' folder{self.COLORS['RESET']}")
    
    def show_cache_cleared(self):
        """Cache cleared"""
        if RICH_AVAILABLE:
            self.console.print("[bold green]Cache cleared[/bold green]")
        else:
            print(f"{self.COLORS['GREEN']}Cache cleared{self.COLORS['RESET']}")
    
    def show_invalid_choice(self):
        """Invalid choice"""
        if RICH_AVAILABLE:
            self.console.print("[bold red]Invalid choice. Try again.[/bold red]")
        else:
            print(f"{self.COLORS['RED']}Invalid choice{self.COLORS['RESET']}")
    
    def show_goodbye(self):
        """Goodbye"""
        if RICH_AVAILABLE:
            self.console.print(Panel(
                "[bold cyan]Goodbye! Thanks for using DB Search Tool[/bold cyan]",
                border_style="cyan"
            ))
        else:
            print(f"\n{self.COLORS['CYAN']}Goodbye!{self.COLORS['RESET']}\n")
    
    def wait_for_key(self):
        """Wait for key press"""
        print(f"\n{self.COLORS['DIM']}Press Enter to continue...{self.COLORS['RESET']}")
        input()
