# Database Search Tool v2.0

Powerful tool for searching information in large databases (TXT, CSV).
Optimized for files 20-70 GB in size.

## Features

- **Parallel search** - uses all CPU cores
- **Large files** - optimization via memory-mapped files
- **Beautiful interface** - colored console UI
- **Caching** - fast repeat searches
- **Statistics** - search tracking
- **Export** - save to TXT, CSV, JSON

## Installation

### Requirements
- Python 3.8 or higher
- Windows 10/11

### Installation Steps

1. **Install Python** (if not installed)
   - Download from https://www.python.org/downloads/
   - Check "Add Python to PATH" during installation

2. **Install dependencies**
   ```
   install.bat
   ```

3. **Put your databases**
   - Copy .txt and .csv files to `bd` folder

4. **Run the program**
   ```
   start.bat
   ```

## Project Structure

```
DB-Search-Tool/
├── main.py                 # Main program file
├── modules/                # Program modules
│   ├── search_engine.py    # Search engine
│   ├── ui_manager.py       # User interface
│   ├── config_manager.py   # Settings
│   ├── logger.py           # Logging
│   ├── file_indexer.py     # File indexing
│   ├── result_exporter.py  # Export results
│   ├── stats_manager.py    # Statistics
│   ├── cache_manager.py    # Caching
│   ├── parallel_processor.py # Parallel processing
│   └── database_manager.py # Database management
├── bd/                     # Database folder
├── results/                # Search results
├── cache/                  # Cache
├── logs/                   # Logs
├── start.bat               # Run program
├── install.bat             # Install dependencies
└── config.json             # Settings (auto-created)
```

## Usage

### Main Menu

```
[1] Search in databases
[2] Index databases
[3] Statistics
[4] Settings
[5] Clear cache
[6] Database info
[0] Exit
```

### What you can search

- **Telegram ID** - numeric account ID
- **Phone number** - any format
- **Name** - first name, last name
- **Email** - email address
- **Username** - @username

### Search Examples

```
Search: 123456789
Search: +79001234567
Search: John Smith
Search: example@mail.ru
Search: @username
```

## Settings (config.json)

```json
{
    "database_path": "bd",
    "max_workers": null,
    "cache_enabled": true,
    "max_results_per_file": 1000,
    "export_format": "txt"
}
```

## Libraries Used

1. **rich** - beautiful tables, panels, progress bars
2. **colorama** - colors in Windows console
3. **pyfiglet** - ASCII art for banner
4. **tqdm** - progress bars
5. **tabulate** - table formatting
6. **blessed** - terminal interface
7. **prompt_toolkit** - improved input
8. **click** - CLI interface

---

**Version:** 2.0
