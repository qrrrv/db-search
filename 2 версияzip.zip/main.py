#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DATABASE SEARCH TOOL v2.5 ULTIMATE
Advanced search in TXT/CSV databases
With themes, filters, and smart detection
"""
import os
import sys
import time
# Fix path - get directory where main.py is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)
sys.path.insert(0, SCRIPT_DIR)
# Now import modules
try:
    from modules.search_engine import SearchEngine
    from modules.ui_manager import UIManager
    from modules.config_manager import ConfigManager
    from modules.logger import Logger
    from modules.file_indexer import FileIndexer
    from modules.result_exporter import ResultExporter
    from modules.stats_manager import StatsManager
    from modules.cache_manager import CacheManager
    from modules.parallel_processor import ParallelProcessor
    from modules.database_manager import DatabaseManager
    from modules.advanced_search import AdvancedSearch
    from modules.theme_manager import ThemeManager
except ImportError as e:
    print(f"[ERROR] Cannot import module: {e}")
    print(f"[INFO] Script directory: {SCRIPT_DIR}")
    print(f"[INFO] Checking modules folder...")
    
    modules_path = os.path.join(SCRIPT_DIR, 'modules')
    if os.path.exists(modules_path):
        print(f"[OK] Modules folder exists")
        print(f"[INFO] Files in modules: {os.listdir(modules_path)}")
    else:
        print(f"[ERROR] Modules folder not found!")
        print(f"[INFO] Please make sure 'modules' folder exists")
    
    input("\nPress Enter to exit...")
    sys.exit(1)
def main():
    """Main function"""
    try:
        # Initialize components
        config = ConfigManager()
        logger = Logger(config)
        theme = ThemeManager(config)
        ui = UIManager(config, theme)
        
        # Clear screen and show banner
        ui.clear_screen()
        ui.show_banner()
        
        # Initialize managers
        cache = CacheManager(config)
        db_manager = DatabaseManager(config, logger)
        indexer = FileIndexer(config, logger)
        processor = ParallelProcessor(config, logger)
        exporter = ResultExporter(config, logger)
        stats = StatsManager(config, logger)
        advanced = AdvancedSearch(config, logger)
        
        # Create search engine
        search_engine = SearchEngine(
            config=config,
            logger=logger,
            cache=cache,
            indexer=indexer,
            processor=processor,
            db_manager=db_manager
        )
        
        # Main loop
        while True:
            ui.show_menu()
            choice = ui.get_user_choice()
            
            if choice == '1':
                # Search in databases
                ui.clear_screen()
                ui.show_search_header()
                
                # Show recent searches
                recent = cache.get_recent_searches(5)
                if recent:
                    ui.show_recent_searches(recent)
                
                query = ui.get_search_query()
                
                if query:
                    # Parse and analyze query
                    parsed = advanced.parse_query(query)
                    ui.show_query_analysis(parsed)
                    
                    ui.show_progress_start()
                    start_time = time.time()
                    
                    results = search_engine.search(query)
                    
                    search_time = time.time() - start_time
                    stats.record_search(query, len(results), search_time)
                    
                    ui.show_results(results, search_engine.get_statistics())
                    
                    if results:
                        # Export menu
                        export_choice = ui.ask_export_format()
                        if export_choice:
                            filepath = exporter.export(results, query, export_choice)
                            if filepath:
                                ui.show_export_success(filepath)
                        
            elif choice == '2':
                # Index databases
                ui.clear_screen()
                ui.show_indexing_header()
                indexer.index_all_databases()
                ui.wait_for_key()
                
            elif choice == '3':
                # Statistics
                ui.clear_screen()
                stats.show_statistics()
                
                # Cache stats
                cache_stats = cache.get_stats()
                ui.show_cache_stats(cache_stats)
                
            elif choice == '4':
                # Settings
                ui.clear_screen()
                config.interactive_settings(ui)
                
            elif choice == '5':
                # Themes
                ui.clear_screen()
                theme.interactive_theme_menu()
                ui = UIManager(config, theme)  # Reload UI with new theme
                
            elif choice == '6':
                # Clear cache
                cache.clear()
                ui.show_cache_cleared()
                
            elif choice == '7':
                # Database info
                ui.clear_screen()
                db_manager.show_database_info()
                
            elif choice == '8':
                # Advanced search
                ui.clear_screen()
                ui.show_advanced_search_menu(advanced)
                
            elif choice == '0' or choice.lower() == 'q':
                ui.show_goodbye()
                break
            else:
                ui.show_invalid_choice()
                
            ui.wait_for_key()
            ui.clear_screen()
            ui.show_banner()
            
    except KeyboardInterrupt:
        print("\n\n[!] Program interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n[ERROR] Critical error: {e}")
        import traceback
        traceback.print_exc()
        input("\nPress Enter to exit...")
        sys.exit(1)
if __name__ == "__main__":
    main()