# -*- coding: utf-8 -*-
"""
Database Search Tool v2.5 Ultimate
All modules
"""
__version__ = "2.5.0"
__author__ = "DB Search Tool"
# Module list for import verification
MODULES = [
    'search_engine',
    'ui_manager', 
    'config_manager',
    'logger',
    'file_indexer',
    'result_exporter',
    'stats_manager',
    'cache_manager',
    'parallel_processor',
    'database_manager',
    'advanced_search',
    'theme_manager'
]