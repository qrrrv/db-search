# -*- coding: utf-8 -*-
"""
Advanced Cache Manager with LRU and Statistics
"""
import os
import json
import time
import hashlib
from typing import Any, Optional, Dict, List
from collections import OrderedDict
class CacheManager:
    """Smart caching with LRU eviction and statistics"""
    
    def __init__(self, config):
        self.config = config
        self.cache_path = config.get('cache_path', 'cache')
        self.cache_enabled = config.get('cache_enabled', True)
        self.cache_ttl = config.get('cache_ttl', 3600)  # 1 hour
        self.max_cache_size = config.get('max_cache_size', 100)  # Max entries
        self.cache = OrderedDict()  # LRU cache
        self.stats = {
            'hits': 0,
            'misses': 0,
            'saves': 0
        }
        
        os.makedirs(self.cache_path, exist_ok=True)
        self._load_cache()
    
    def _get_cache_file(self) -> str:
        """Path to cache file"""
        return os.path.join(self.cache_path, 'search_cache.json')
    
    def _get_stats_file(self) -> str:
        """Path to stats file"""
        return os.path.join(self.cache_path, 'cache_stats.json')
    
    def _load_cache(self):
        """Load cache from file"""
        cache_file = self._get_cache_file()
        stats_file = self._get_stats_file()
        
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.cache = OrderedDict(data.get('cache', {}))
                self._cleanup_expired()
            except:
                self.cache = OrderedDict()
        
        if os.path.exists(stats_file):
            try:
                with open(stats_file, 'r', encoding='utf-8') as f:
                    self.stats = json.load(f)
            except:
                pass
    
    def _save_cache(self):
        """Save cache to file"""
        try:
            with open(self._get_cache_file(), 'w', encoding='utf-8') as f:
                json.dump({'cache': dict(self.cache)}, f, ensure_ascii=False)
            with open(self._get_stats_file(), 'w', encoding='utf-8') as f:
                json.dump(self.stats, f)
        except:
            pass
    
    def _get_key(self, query: str) -> str:
        """Generate cache key"""
        return hashlib.md5(query.lower().strip().encode()).hexdigest()
    
    def get(self, query: str) -> Optional[List[Dict]]:
        """Get from cache with LRU update"""
        if not self.cache_enabled:
            return None
        
        key = self._get_key(query)
        
        if key in self.cache:
            entry = self.cache[key]
            
            # Check TTL
            if time.time() - entry.get('timestamp', 0) < self.cache_ttl:
                # Move to end (most recently used)
                self.cache.move_to_end(key)
                self.stats['hits'] += 1
                return entry.get('data')
            else:
                # Expired
                del self.cache[key]
        
        self.stats['misses'] += 1
        return None
    
    def set(self, query: str, data: List[Dict]):
        """Save to cache with LRU eviction"""
        if not self.cache_enabled:
            return
        
        key = self._get_key(query)
        
        # Evict oldest if cache is full
        while len(self.cache) >= self.max_cache_size:
            self.cache.popitem(last=False)
        
        self.cache[key] = {
            'query': query,
            'data': data[:1000],  # Limit size
            'timestamp': time.time(),
            'results_count': len(data)
        }
        
        self.stats['saves'] += 1
        self._save_cache()
    
    def _cleanup_expired(self):
        """Clean expired entries"""
        current_time = time.time()
        expired_keys = [
            key for key, entry in self.cache.items()
            if current_time - entry.get('timestamp', 0) >= self.cache_ttl
        ]
        
        for key in expired_keys:
            del self.cache[key]
        
        if expired_keys:
            self._save_cache()
    
    def clear(self):
        """Clear all cache"""
        self.cache = OrderedDict()
        self.stats = {'hits': 0, 'misses': 0, 'saves': 0}
        
        # Remove all cache files
        for f in os.listdir(self.cache_path):
            filepath = os.path.join(self.cache_path, f)
            try:
                if os.path.isfile(filepath):
                    os.remove(filepath)
            except:
                pass
    
    def get_size(self) -> int:
        """Cache size"""
        return len(self.cache)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total = self.stats['hits'] + self.stats['misses']
        hit_rate = (self.stats['hits'] / total * 100) if total > 0 else 0
        
        return {
            'entries': len(self.cache),
            'hits': self.stats['hits'],
            'misses': self.stats['misses'],
            'saves': self.stats['saves'],
            'hit_rate': f"{hit_rate:.1f}%"
        }
    
    def get_recent_searches(self, limit: int = 10) -> List[Dict]:
        """Get recent searches from cache"""
        recent = []
        for key in reversed(list(self.cache.keys())[:limit]):
            entry = self.cache[key]
            recent.append({
                'query': entry.get('query', ''),
                'results': entry.get('results_count', 0),
                'time': time.strftime('%H:%M:%S', 
                    time.localtime(entry.get('timestamp', 0)))
            })
        return recent
