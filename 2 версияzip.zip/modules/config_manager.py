# -*- coding: utf-8 -*-
"""
Configuration Manager v2.5
With extended settings and presets
"""
import os
import json
import multiprocessing
from typing import Any, Dict, Optional
class ConfigManager:
    """Program settings manager with presets"""
    
    # Performance presets
    PRESETS = {
        'low': {
            'max_workers': 2,
            'max_results_per_file': 500,
            'max_total_results': 5000,
            'use_mmap_threshold': 200 * 1024 * 1024,
            'chunk_size': 512 * 1024,
        },
        'medium': {
            'max_workers': None,  # Auto
            'max_results_per_file': 1000,
            'max_total_results': 10000,
            'use_mmap_threshold': 100 * 1024 * 1024,
            'chunk_size': 1024 * 1024,
        },
        'high': {
            'max_workers': None,  # Auto
            'max_results_per_file': 2000,
            'max_total_results': 50000,
            'use_mmap_threshold': 50 * 1024 * 1024,
            'chunk_size': 2 * 1024 * 1024,
        },
        'ultra': {
            'max_workers': None,  # Auto x2
            'max_results_per_file': 5000,
            'max_total_results': 100000,
            'use_mmap_threshold': 10 * 1024 * 1024,
            'chunk_size': 4 * 1024 * 1024,
        }
    }
    
    DEFAULT_CONFIG = {
        # Paths
        'database_path': 'bd',
        'results_path': 'results',
        'cache_path': 'cache',
        'logs_path': 'logs',
        
        # File settings
        'file_extensions': ['.txt', '.csv'],
        'encoding_priority': ['utf-8', 'cp1251', 'latin-1', 'cp866'],
        
        # Performance
        'max_workers': None,  # Auto-detect
        'max_results_per_file': 1000,
        'max_total_results': 10000,
        'use_mmap_threshold': 104857600,  # 100MB
        'chunk_size': 1048576,  # 1MB
        'performance_preset': 'medium',
        
        # Cache
        'cache_enabled': True,
        'cache_ttl': 3600,
        'max_cache_size': 100,
        
        # UI
        'show_progress': True,
        'color_output': True,
        'theme': 'default',
        
        # Export
        'export_format': 'txt',
        
        # Logging
        'log_level': 'INFO',
        'log_to_file': True,
    }
    
    def __init__(self, config_file: str = 'config.json'):
        self.config_file = config_file
        self.config = self.DEFAULT_CONFIG.copy()
        self._load_config()
        self._ensure_directories()
    
    def _load_config(self):
        """Load configuration from file"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                    self.config.update(loaded)
            except Exception as e:
                print(f"[!] Config load error: {e}")
        else:
            self._save_config()
    
    def _save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"[!] Config save error: {e}")
    
    def _ensure_directories(self):
        """Create necessary directories"""
        dirs = [
            self.config['database_path'],
            self.config['results_path'],
            self.config['cache_path'],
            self.config['logs_path'],
        ]
        for d in dirs:
            os.makedirs(d, exist_ok=True)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value"""
        value = self.config.get(key, default)
        
        # Auto-detect workers if None
        if key == 'max_workers' and value is None:
            return multiprocessing.cpu_count()
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value"""
        self.config[key] = value
        self._save_config()
    
    def get_all(self) -> Dict:
        """Get all configuration"""
        return self.config.copy()
    
    def apply_preset(self, preset_name: str) -> bool:
        """Apply performance preset"""
        if preset_name not in self.PRESETS:
            return False
        
        preset = self.PRESETS[preset_name]
        for key, value in preset.items():
            self.config[key] = value
        
        self.config['performance_preset'] = preset_name
        self._save_config()
        return True
    
    def reset_to_default(self):
        """Reset to default settings"""
        self.config = self.DEFAULT_CONFIG.copy()
        self._save_config()
    
    def interactive_settings(self, ui):
        """Interactive settings menu"""
        while True:
            cpu_count = multiprocessing.cpu_count()
            workers = self.config['max_workers'] or cpu_count
            
            print("\n" + "=" * 60)
            print("                    SETTINGS")
            print("=" * 60)
            
            print("\n  [PATHS]")
            print(f"    1. Database folder: {self.config['database_path']}")
            print(f"    2. Results folder:  {self.config['results_path']}")
            
            print("\n  [PERFORMANCE]")
            print(f"    3. Preset: {self.config.get('performance_preset', 'medium').upper()}")
            print(f"    4. Workers: {workers} (CPU cores: {cpu_count})")
            print(f"    5. Max results per file: {self.config['max_results_per_file']}")
            print(f"    6. Max total results: {self.config['max_total_results']}")
            
            print("\n  [CACHE]")
            print(f"    7. Cache: {'ON' if self.config['cache_enabled'] else 'OFF'}")
            print(f"    8. Cache TTL: {self.config['cache_ttl']} sec")
            
            print("\n  [EXPORT]")
            print(f"    9. Default format: {self.config['export_format'].upper()}")
            
            print("\n  [OTHER]")
            print(f"    P. Apply preset (low/medium/high/ultra)")
            print(f"    R. Reset to default")
            print(f"    0. Back")
            
            print("\n" + "=" * 60)
            
            choice = input("\nSelect option: ").strip().lower()
            
            if choice == '0':
                break
            elif choice == '1':
                new_path = input("New database path: ").strip()
                if new_path:
                    self.set('database_path', new_path)
                    print("[OK] Path updated")
            elif choice == '2':
                new_path = input("New results path: ").strip()
                if new_path:
                    self.set('results_path', new_path)
                    print("[OK] Path updated")
            elif choice == '3' or choice == 'p':
                print("\nAvailable presets:")
                print("  low    - For weak PCs")
                print("  medium - Balanced (default)")
                print("  high   - For powerful PCs")
                print("  ultra  - Maximum performance")
                preset = input("\nEnter preset name: ").strip().lower()
                if self.apply_preset(preset):
                    print(f"[OK] Preset '{preset}' applied")
                else:
                    print("[!] Unknown preset")
            elif choice == '4':
                workers = input(f"Workers (1-{cpu_count*2}, Enter for auto): ").strip()
                if workers:
                    self.set('max_workers', int(workers))
                else:
                    self.set('max_workers', None)
                print("[OK] Updated")
            elif choice == '5':
                val = input("Max results per file: ").strip()
                if val.isdigit():
                    self.set('max_results_per_file', int(val))
                    print("[OK] Updated")
            elif choice == '6':
                val = input("Max total results: ").strip()
                if val.isdigit():
                    self.set('max_total_results', int(val))
                    print("[OK] Updated")
            elif choice == '7':
                self.set('cache_enabled', not self.config['cache_enabled'])
                print(f"[OK] Cache: {'ON' if self.config['cache_enabled'] else 'OFF'}")
            elif choice == '8':
                val = input("Cache TTL (seconds): ").strip()
                if val.isdigit():
                    self.set('cache_ttl', int(val))
                    print("[OK] Updated")
            elif choice == '9':
                fmt = input("Format (txt/csv/json): ").strip().lower()
                if fmt in ['txt', 'csv', 'json']:
                    self.set('export_format', fmt)
                    print("[OK] Updated")
            elif choice == 'r':
                confirm = input("Reset all settings? (y/n): ").strip().lower()
                if confirm == 'y':
                    self.reset_to_default()
                    print("[OK] Settings reset to default")
