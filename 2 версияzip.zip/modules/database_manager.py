# -*- coding: utf-8 -*-
"""
Database Manager
"""

import os
from typing import Dict, List, Any
from datetime import datetime

class DatabaseManager:
    """Database management"""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.db_path = config.get('database_path', 'bd')
        
        os.makedirs(self.db_path, exist_ok=True)
    
    def get_database_list(self) -> List[Dict[str, Any]]:
        """Get list of all databases"""
        databases = []
        extensions = self.config.get('file_extensions', ['.txt', '.csv'])
        
        for root, dirs, files in os.walk(self.db_path):
            for filename in files:
                if any(filename.lower().endswith(ext) for ext in extensions):
                    filepath = os.path.join(root, filename)
                    
                    try:
                        stat = os.stat(filepath)
                        databases.append({
                            'name': filename,
                            'path': filepath,
                            'relative_path': os.path.relpath(filepath, self.db_path),
                            'size': stat.st_size,
                            'size_mb': stat.st_size / (1024 * 1024),
                            'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                            'type': os.path.splitext(filename)[1].lower()
                        })
                    except Exception as e:
                        self.logger.error(f"Error getting info for {filepath}: {e}")
        
        return databases
    
    def get_total_size(self) -> int:
        """Total size of all databases"""
        total = 0
        for db in self.get_database_list():
            total += db['size']
        return total
    
    def show_database_info(self):
        """Show database information"""
        databases = self.get_database_list()
        
        print("\n" + "=" * 70)
        print("                    DATABASE INFORMATION")
        print("=" * 70)
        
        if not databases:
            print(f"\n  [!] No databases found in '{self.db_path}' folder")
            print(f"  Put .txt or .csv files in this folder")
            print("\n" + "=" * 70)
            return
        
        folders = {}
        for db in databases:
            folder = os.path.dirname(db['relative_path']) or 'root folder'
            if folder not in folders:
                folders[folder] = []
            folders[folder].append(db)
        
        total_size = 0
        total_files = 0
        
        for folder, files in folders.items():
            print(f"\n  [FOLDER] {folder}/")
            
            for db in files:
                size_str = self._format_size(db['size'])
                print(f"     [FILE] {db['name']:<40} {size_str:>12}")
                total_size += db['size']
                total_files += 1
        
        print("\n" + "-" * 70)
        print(f"  TOTAL: {total_files} files, {self._format_size(total_size)}")
        print("=" * 70)
    
    def _format_size(self, size_bytes: int) -> str:
        """Format file size"""
        if size_bytes >= 1024 ** 3:
            return f"{size_bytes / (1024 ** 3):.2f} GB"
        elif size_bytes >= 1024 ** 2:
            return f"{size_bytes / (1024 ** 2):.2f} MB"
        elif size_bytes >= 1024:
            return f"{size_bytes / 1024:.2f} KB"
        else:
            return f"{size_bytes} B"
    
    def validate_databases(self) -> Dict[str, Any]:
        """Validate database integrity"""
        results = {
            'valid': [],
            'errors': [],
            'warnings': []
        }
        
        for db in self.get_database_list():
            try:
                with open(db['path'], 'r', encoding='utf-8', errors='ignore') as f:
                    first_line = f.readline()
                    
                if first_line:
                    results['valid'].append(db['name'])
                else:
                    results['warnings'].append(f"{db['name']}: empty file")
                    
            except Exception as e:
                results['errors'].append(f"{db['name']}: {str(e)}")
        
        return results
