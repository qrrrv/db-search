# -*- coding: utf-8 -*-
"""
Advanced File Indexer with Smart Detection
"""
import os
import time
import json
import hashlib
import re
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor
import multiprocessing
class FileIndexer:
    """Smart indexer for fast search in large databases"""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.index = {}
        self.stats = {
            'files': 0,
            'records': 0,
            'time': 0,
            'total_size': 0
        }
        self.index_file = os.path.join(config.get('cache_path', 'cache'), 'index.json')
        self.field_stats = {}  # Statistics by field types
        self._load_index()
    
    def _load_index(self):
        """Load existing index"""
        if os.path.exists(self.index_file):
            try:
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.index = data.get('index', {})
                    self.field_stats = data.get('field_stats', {})
                self.logger.info(f"Index loaded: {len(self.index)} files")
            except Exception as e:
                self.logger.error(f"Error loading index: {e}")
                self.index = {}
    
    def _save_index(self):
        """Save index"""
        try:
            data = {
                'index': self.index,
                'field_stats': self.field_stats,
                'updated': time.strftime('%Y-%m-%d %H:%M:%S')
            }
            with open(self.index_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.logger.info("Index saved")
        except Exception as e:
            self.logger.error(f"Error saving index: {e}")
    
    def index_all_databases(self):
        """Index all databases with progress"""
        start_time = time.time()
        db_path = self.config.get('database_path', 'bd')
        
        if not os.path.exists(db_path):
            os.makedirs(db_path, exist_ok=True)
            self.logger.warning(f"Created empty directory: {db_path}")
            print(f"\n[!] Folder '{db_path}' is empty. Add your databases there.")
            return
        
        files = self._get_all_files(db_path)
        self.stats['files'] = len(files)
        
        if not files:
            print(f"\n[!] No .txt or .csv files found in '{db_path}' folder")
            return
        
        print(f"\n[*] Found {len(files)} files for indexing...")
        print("[*] Analyzing structure...\n")
        
        max_workers = self.config.get('max_workers') or multiprocessing.cpu_count()
        total_size = 0
        
        # Progress display
        for i, file_path in enumerate(files, 1):
            size = os.path.getsize(file_path)
            total_size += size
            size_mb = size / (1024 * 1024)
            
            print(f"  [{i}/{len(files)}] {os.path.basename(file_path)[:40]:<40} {size_mb:>8.2f} MB")
        
        self.stats['total_size'] = total_size
        print(f"\n[*] Total size: {total_size / (1024**3):.2f} GB")
        print("[*] Indexing...\n")
        
        # Parallel indexing
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            results = list(executor.map(self._index_file, files))
        
        self.stats['records'] = sum(results)
        self.stats['time'] = time.time() - start_time
        
        self._save_index()
        
        print(f"\n[OK] Indexing complete!")
        print(f"     Files: {self.stats['files']}")
        print(f"     Records: {self.stats['records']:,}")
        print(f"     Time: {self.stats['time']:.2f} sec")
        
        self.logger.info(
            f"Indexing complete: {self.stats['files']} files, "
            f"{self.stats['records']} records in {self.stats['time']:.2f} sec"
        )
    
    def _get_all_files(self, path: str) -> List[str]:
        """Get list of all database files"""
        files = []
        extensions = self.config.get('file_extensions', ['.txt', '.csv'])
        
        for root, dirs, filenames in os.walk(path):
            for filename in filenames:
                if any(filename.lower().endswith(ext) for ext in extensions):
                    files.append(os.path.join(root, filename))
        
        return sorted(files, key=lambda x: os.path.getsize(x), reverse=True)
    
    def _index_file(self, file_path: str) -> int:
        """Index single file with structure detection"""
        try:
            file_hash = self._get_file_hash(file_path)
            
            # Check if already indexed
            if file_path in self.index:
                if self.index[file_path].get('hash') == file_hash:
                    return self.index[file_path].get('lines', 0)
            
            lines = 0
            file_size = os.path.getsize(file_path)
            sample_data = []
            detected_fields = set()
            delimiter = None
            
            encodings = self.config.get('encoding_priority', ['utf-8', 'cp1251', 'latin-1'])
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                        # Read first 100 lines for analysis
                        for i, line in enumerate(f):
                            lines += 1
                            if i < 100:
                                sample_data.append(line.strip())
                    break
                except:
                    continue
            
            # Detect delimiter and fields
            if sample_data:
                delimiter = self._detect_delimiter(sample_data[0])
                detected_fields = self._detect_fields(sample_data[:20])
            
            self.index[file_path] = {
                'hash': file_hash,
                'lines': lines,
                'size': file_size,
                'name': os.path.basename(file_path),
                'delimiter': delimiter,
                'fields': list(detected_fields),
                'indexed_at': time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Update field statistics
            for field in detected_fields:
                self.field_stats[field] = self.field_stats.get(field, 0) + 1
            
            return lines
            
        except Exception as e:
            self.logger.error(f"Error indexing {file_path}: {e}")
            return 0
    
    def _detect_delimiter(self, line: str) -> str:
        """Detect field delimiter"""
        delimiters = {
            ':': line.count(':'),
            ';': line.count(';'),
            ',': line.count(','),
            '\t': line.count('\t'),
            '|': line.count('|')
        }
        return max(delimiters, key=delimiters.get)
    
    def _detect_fields(self, lines: List[str]) -> set:
        """Detect field types in data"""
        fields = set()
        
        patterns = {
            'telegram_id': r'\b\d{6,12}\b',
            'phone': r'[\+]?[78]?\d{10,11}',
            'email': r'[\w\.\-]+@[\w\.\-]+\.\w+',
            'username': r'@[\w\d_]{3,}',
            'ip_address': r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
            'password': r'(?<=:)[^\s:]{6,}$',
            'name_ru': r'[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+',
            'name_en': r'[A-Z][a-z]+\s+[A-Z][a-z]+'
        }
        
        for line in lines:
            for field_name, pattern in patterns.items():
                if re.search(pattern, line):
                    fields.add(field_name)
        
        return fields
    
    def _get_file_hash(self, file_path: str) -> str:
        """Get file hash (fast method based on size and mtime)"""
        try:
            stat = os.stat(file_path)
            return f"{stat.st_size}_{stat.st_mtime}"
        except:
            return ""
    
    def get_stats(self) -> Dict[str, Any]:
        """Get indexing statistics"""
        return self.stats.copy()
    
    def is_file_indexed(self, file_path: str) -> bool:
        """Check if file is indexed"""
        return file_path in self.index
    
    def get_file_info(self, file_path: str) -> Optional[Dict]:
        """Get indexed file info"""
        return self.index.get(file_path)
    
    def get_field_stats(self) -> Dict[str, int]:
        """Get field type statistics"""
        return self.field_stats.copy()
