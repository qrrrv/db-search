# -*- coding: utf-8 -*-
"""
Система логирования
"""

import os
import logging
from datetime import datetime
from typing import Optional

class Logger:
    """Менеджер логирования"""
    
    def __init__(self, config):
        self.config = config
        self.log_path = config.get('logs_path', 'logs')
        self.log_level = config.get('log_level', 'INFO')
        
        # Создаём директорию для логов
        os.makedirs(self.log_path, exist_ok=True)
        
        # Настройка логгера
        self.logger = logging.getLogger('DBSearch')
        self.logger.setLevel(getattr(logging, self.log_level))
        
        # Файловый хендлер
        log_file = os.path.join(
            self.log_path, 
            f"search_{datetime.now().strftime('%Y%m%d')}.log"
        )
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        
        # Форматирование
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)
        
        # Добавляем хендлер
        if not self.logger.handlers:
            self.logger.addHandler(file_handler)
    
    def info(self, message: str):
        """Информационное сообщение"""
        self.logger.info(message)
    
    def warning(self, message: str):
        """Предупреждение"""
        self.logger.warning(message)
    
    def error(self, message: str):
        """Ошибка"""
        self.logger.error(message)
    
    def debug(self, message: str):
        """Отладка"""
        self.logger.debug(message)
    
    def critical(self, message: str):
        """Критическая ошибка"""
        self.logger.critical(message)
