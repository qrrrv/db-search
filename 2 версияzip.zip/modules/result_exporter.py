# -*- coding: utf-8 -*-
"""
Экспортер результатов поиска
"""

import os
import json
import csv
from datetime import datetime
from typing import List, Dict, Any

class ResultExporter:
    """Экспорт результатов в различные форматы"""
    
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.results_path = config.get('results_path', 'results')
        os.makedirs(self.results_path, exist_ok=True)
    
    def export(self, results: List[Dict], query: str, format: str = None):
        """Экспорт результатов"""
        if not results:
            return None
        
        format = format or self.config.get('export_format', 'txt')
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        safe_query = "".join(c for c in query if c.isalnum() or c in ' _-')[:30]
        
        filename = f"search_{safe_query}_{timestamp}"
        
        if format == 'txt':
            return self._export_txt(results, query, filename)
        elif format == 'csv':
            return self._export_csv(results, query, filename)
        elif format == 'json':
            return self._export_json(results, query, filename)
        else:
            return self._export_txt(results, query, filename)
    
    def _export_txt(self, results: List[Dict], query: str, filename: str) -> str:
        """Экспорт в TXT"""
        filepath = os.path.join(self.results_path, f"{filename}.txt")
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write("=" * 80 + "\n")
                f.write(f"  РЕЗУЛЬТАТЫ ПОИСКА: {query}\n")
                f.write(f"  Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"  Найдено: {len(results)} записей\n")
                f.write("=" * 80 + "\n\n")
                
                for i, result in enumerate(results, 1):
                    f.write(f"[{i}] Файл: {result.get('file', 'N/A')}\n")
                    f.write(f"    Строка: {result.get('line_number', 'N/A')}\n")
                    f.write(f"    Данные: {result.get('raw_data', '')}\n")
                    
                    parsed = result.get('parsed', {})
                    if parsed:
                        f.write(f"    Распознано:\n")
                        for key, value in parsed.items():
                            f.write(f"      - {key}: {value}\n")
                    
                    f.write("-" * 80 + "\n")
            
            self.logger.info(f"Экспорт TXT: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Ошибка экспорта TXT: {e}")
            return None
    
    def _export_csv(self, results: List[Dict], query: str, filename: str) -> str:
        """Экспорт в CSV"""
        filepath = os.path.join(self.results_path, f"{filename}.csv")
        
        try:
            with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.writer(f, delimiter=';')
                
                # Заголовки
                writer.writerow([
                    '№', 'Файл', 'Строка', 'Данные', 
                    'Telegram ID', 'Телефон', 'Email', 'Username', 'Имя'
                ])
                
                for i, result in enumerate(results, 1):
                    parsed = result.get('parsed', {})
                    writer.writerow([
                        i,
                        result.get('file', ''),
                        result.get('line_number', ''),
                        result.get('raw_data', ''),
                        parsed.get('telegram_id', ''),
                        parsed.get('phone', ''),
                        parsed.get('email', ''),
                        parsed.get('username', ''),
                        parsed.get('name', '')
                    ])
            
            self.logger.info(f"Экспорт CSV: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Ошибка экспорта CSV: {e}")
            return None
    
    def _export_json(self, results: List[Dict], query: str, filename: str) -> str:
        """Экспорт в JSON"""
        filepath = os.path.join(self.results_path, f"{filename}.json")
        
        try:
            export_data = {
                'query': query,
                'timestamp': datetime.now().isoformat(),
                'total_results': len(results),
                'results': results
            }
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"Экспорт JSON: {filepath}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Ошибка экспорта JSON: {e}")
            return None
