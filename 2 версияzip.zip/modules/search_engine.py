# -*- coding: utf-8 -*-
"""
Advanced Search Engine v2.5
High-performance search with smart detection
"""
import os
import re
import csv
import mmap
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Any, Optional, Generator
import multiprocessing
import time
class SearchEngine:
    """Powerful search engine for large databases"""
    
    def __init__(self, config, logger, cache, indexer, processor, db_manager):
        self.config = config
        self.logger = logger
        self.cache = cache
        self.indexer = indexer
        self.processor = processor
        self.db_manager = db_manager
        self.results = []
        self.total_lines_searched = 0
        self.files_searched = 0
        self.search_time = 0
        self._lock = threading.Lock()
        
    def search(self, query: str, filters: Dict = None) -> List[Dict[str, Any]]:
        """Main search method"""
        start_time = time.time()
        self.results = []
        self.total_lines_searched = 0
        self.files_searched = 0
        
        # Normalize query
        query = query.strip()
        if not query:
            return []
        
        # Check cache first
        cached = self.cache.get(query)
        if cached:
            self.logger.info(f"Cache hit for: {query}")
            self.search_time = time.time() - start_time
            return cached
        
        # Get database files
        db_path = self.config.get('database_path', 'bd')
        files = self._get_database_files(db_path)
        
        if not files:
            self.logger.warning("No database files found!")
            return []
        
        self.logger.info(f"Searching in {len(files)} files...")
        
        # Prepare search variations
        search_queries = self._prepare_search_queries(query)
        
        # Parallel search
        max_workers = self.config.get('max_workers') or multiprocessing.cpu_count()
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(self._search_file, file_path, search_queries): file_path 
                for file_path in files
            }
            
            for future in as_completed(futures):
                file_path = futures[future]
                try:
                    file_results = future.result()
                    with self._lock:
                        self.results.extend(file_results)
                        self.files_searched += 1
                except Exception as e:
                    self.logger.error(f"Error searching {file_path}: {e}")
        
        # Remove duplicates
        self.results = self._deduplicate_results(self.results)
        
        # Limit results
        max_results = self.config.get('max_total_results', 10000)
        if len(self.results) > max_results:
            self.results = self.results[:max_results]
        
        # Save to cache
        if self.results:
            self.cache.set(query, self.results)
        
        self.search_time = time.time() - start_time
        self.logger.info(f"Search complete. Found: {len(self.results)} in {self.search_time:.2f}s")
        
        return self.results
    
    def _prepare_search_queries(self, query: str) -> List[str]:
        """Prepare search query variations"""
        queries = [query.lower()]
        
        # Phone number variations
        if re.match(r'^[\+]?[78]?\d{10,11}$', query.replace(' ', '').replace('-', '')):
            digits = re.sub(r'\D', '', query)
            if len(digits) == 11:
                # 79001234567, 89001234567, 9001234567
                queries.append(digits)
                queries.append('7' + digits[1:])
                queries.append('8' + digits[1:])
                queries.append(digits[1:])
                # With format
                queries.append(f"+7{digits[1:]}")
        
        # Cyrillic name variations
        if re.match(r'^[А-ЯЁа-яё\s]+$', query):
            # Try different orders: "Иван Петров" -> "Петров Иван"
            parts = query.split()
            if len(parts) >= 2:
                queries.append(' '.join(reversed(parts)))
        
        return list(set(queries))
    
    def _get_database_files(self, path: str) -> List[str]:
        """Get list of database files"""
        files = []
        extensions = self.config.get('file_extensions', ['.txt', '.csv'])
        
        if not os.path.exists(path):
            os.makedirs(path, exist_ok=True)
            return files
        
        for root, dirs, filenames in os.walk(path):
            for filename in filenames:
                if any(filename.lower().endswith(ext) for ext in extensions):
                    files.append(os.path.join(root, filename))
        
        # Sort by size (larger files first for better load balancing)
        files.sort(key=lambda x: os.path.getsize(x), reverse=True)
        
        return files
    
    def _search_file(self, file_path: str, queries: List[str]) -> List[Dict[str, Any]]:
        """Search in single file"""
        results = []
        
        try:
            file_size = os.path.getsize(file_path)
            
            # Use mmap for large files (>100MB)
            if file_size > 100 * 1024 * 1024:
                results = self._search_file_mmap(file_path, queries)
            else:
                results = self._search_file_standard(file_path, queries)
                
        except Exception as e:
            self.logger.error(f"Error reading {file_path}: {e}")
        
        return results
    
    def _search_file_mmap(self, file_path: str, queries: List[str]) -> List[Dict[str, Any]]:
        """Search using memory-mapped files (for large files)"""
        results = []
        query_bytes_list = [q.encode('utf-8', errors='ignore') for q in queries]
        
        try:
            with open(file_path, 'rb') as f:
                with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
                    line_num = 0
                    start = 0
                    max_results = self.config.get('max_results_per_file', 1000)
                    
                    while True:
                        line_end = mm.find(b'\n', start)
                        if line_end == -1:
                            # Last line
                            line = mm[start:]
                            line_lower = line.lower()
                            for qb in query_bytes_list:
                                if qb in line_lower:
                                    results.append(self._create_result(
                                        file_path, line_num, 
                                        line.decode('utf-8', errors='ignore').strip()
                                    ))
                                    break
                            break
                        
                        line = mm[start:line_end]
                        line_lower = line.lower()
                        line_num += 1
                        
                        with self._lock:
                            self.total_lines_searched += 1
                        
                        for qb in query_bytes_list:
                            if qb in line_lower:
                                results.append(self._create_result(
                                    file_path, line_num,
                                    line.decode('utf-8', errors='ignore').strip()
                                ))
                                break
                        
                        start = line_end + 1
                        
                        if len(results) >= max_results:
                            break
                            
        except Exception as e:
            self.logger.error(f"MMAP error in {file_path}: {e}")
        
        return results
    
    def _search_file_standard(self, file_path: str, queries: List[str]) -> List[Dict[str, Any]]:
        """Standard line-by-line search"""
        results = []
        encodings = ['utf-8', 'cp1251', 'latin-1', 'cp866']
        max_results = self.config.get('max_results_per_file', 1000)
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                    for line_num, line in enumerate(f, 1):
                        with self._lock:
                            self.total_lines_searched += 1
                        
                        line_lower = line.lower()
                        
                        for query in queries:
                            if query in line_lower:
                                results.append(self._create_result(file_path, line_num, line.strip()))
                                break
                        
                        if len(results) >= max_results:
                            break
                break
            except UnicodeDecodeError:
                continue
            except Exception as e:
                self.logger.error(f"Error reading {file_path} ({encoding}): {e}")
                break
        
        return results
    
    def _create_result(self, file_path: str, line_num: int, line: str) -> Dict[str, Any]:
        """Create search result"""
        parsed_data = self._parse_line(line, file_path)
        
        return {
            'file': os.path.basename(file_path),
            'file_path': file_path,
            'line_number': line_num,
            'raw_data': line,
            'parsed': parsed_data
        }
    
    def _parse_line(self, line: str, file_path: str) -> Dict[str, Any]:
        """Parse data from line"""
        parsed = {}
        
        # Detect delimiter
        if file_path.endswith('.csv'):
            parts = line.split(',')
        elif ':' in line and line.count(':') >= 1:
            parts = line.split(':')
        elif ';' in line:
            parts = line.split(';')
        elif '\t' in line:
            parts = line.split('\t')
        elif '|' in line:
            parts = line.split('|')
        else:
            parts = line.split()
        
        # Extract known fields
        patterns = {
            'telegram_id': r'^\d{6,12}$',
            'phone': r'^[\+]?[78]?\d{10,11}$',
            'email': r'^[\w\.\-]+@[\w\.\-]+\.\w+$',
            'username': r'^@[\w\d_]{3,}$',
            'ip': r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$',
            'name': r'^[А-ЯЁA-Z][а-яёa-z]{1,}$',
        }
        
        for part in parts:
            part = part.strip()
            if not part:
                continue
            
            for field_name, pattern in patterns.items():
                if re.match(pattern, part):
                    if field_name not in parsed:
                        parsed[field_name] = part
                    elif field_name == 'name':
                        if 'surname' not in parsed:
                            parsed['surname'] = part
                    break
        
        return parsed
    
    def _deduplicate_results(self, results: List[Dict]) -> List[Dict]:
        """Remove duplicate results"""
        seen = set()
        unique = []
        
        for r in results:
            key = (r.get('file'), r.get('line_number'), r.get('raw_data', '')[:100])
            if key not in seen:
                seen.add(key)
                unique.append(r)
        
        return unique
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get search statistics"""
        return {
            'total_results': len(self.results),
            'files_searched': self.files_searched,
            'lines_searched': self.total_lines_searched,
            'search_time': round(self.search_time, 2)
        }