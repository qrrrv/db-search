# -*- coding: utf-8 -*-
"""
Theme Manager - Customizable Console Themes
"""
import os
import json
from typing import Dict, Any, Optional
class ThemeManager:
    """Manage console themes and colors"""
    
    # Predefined themes
    THEMES = {
        'default': {
            'name': 'Default Blue',
            'primary': 'cyan',
            'secondary': 'blue',
            'accent': 'yellow',
            'success': 'green',
            'error': 'red',
            'warning': 'yellow',
            'text': 'white',
            'dim': 'bright_black',
            'banner_style': 'bold cyan',
            'menu_style': 'cyan',
            'result_style': 'green',
            'border': 'blue'
        },
        'hacker': {
            'name': 'Hacker Green',
            'primary': 'green',
            'secondary': 'bright_green',
            'accent': 'white',
            'success': 'bright_green',
            'error': 'red',
            'warning': 'yellow',
            'text': 'green',
            'dim': 'dark_green',
            'banner_style': 'bold green',
            'menu_style': 'green',
            'result_style': 'bright_green',
            'border': 'green'
        },
        'neon': {
            'name': 'Neon Purple',
            'primary': 'magenta',
            'secondary': 'bright_magenta',
            'accent': 'cyan',
            'success': 'bright_cyan',
            'error': 'bright_red',
            'warning': 'bright_yellow',
            'text': 'white',
            'dim': 'bright_black',
            'banner_style': 'bold magenta',
            'menu_style': 'magenta',
            'result_style': 'bright_magenta',
            'border': 'magenta'
        },
        'fire': {
            'name': 'Fire Red',
            'primary': 'red',
            'secondary': 'bright_red',
            'accent': 'yellow',
            'success': 'green',
            'error': 'bright_red',
            'warning': 'bright_yellow',
            'text': 'white',
            'dim': 'bright_black',
            'banner_style': 'bold red',
            'menu_style': 'red',
            'result_style': 'bright_red',
            'border': 'red'
        },
        'ocean': {
            'name': 'Ocean Blue',
            'primary': 'blue',
            'secondary': 'cyan',
            'accent': 'bright_cyan',
            'success': 'bright_green',
            'error': 'red',
            'warning': 'yellow',
            'text': 'bright_white',
            'dim': 'bright_black',
            'banner_style': 'bold blue',
            'menu_style': 'blue',
            'result_style': 'cyan',
            'border': 'blue'
        },
        'gold': {
            'name': 'Gold Premium',
            'primary': 'yellow',
            'secondary': 'bright_yellow',
            'accent': 'white',
            'success': 'bright_green',
            'error': 'red',
            'warning': 'bright_yellow',
            'text': 'bright_white',
            'dim': 'bright_black',
            'banner_style': 'bold yellow',
            'menu_style': 'yellow',
            'result_style': 'bright_yellow',
            'border': 'yellow'
        },
        'minimal': {
            'name': 'Minimal White',
            'primary': 'white',
            'secondary': 'bright_white',
            'accent': 'cyan',
            'success': 'green',
            'error': 'red',
            'warning': 'yellow',
            'text': 'white',
            'dim': 'bright_black',
            'banner_style': 'bold white',
            'menu_style': 'white',
            'result_style': 'white',
            'border': 'white'
        },
        'matrix': {
            'name': 'Matrix',
            'primary': 'bright_green',
            'secondary': 'green',
            'accent': 'bright_white',
            'success': 'bright_green',
            'error': 'bright_red',
            'warning': 'bright_yellow',
            'text': 'bright_green',
            'dim': 'green',
            'banner_style': 'bold bright_green',
            'menu_style': 'bright_green',
            'result_style': 'green',
            'border': 'bright_green'
        }
    }
    
    # ANSI color codes
    ANSI_COLORS = {
        'black': '\033[30m',
        'red': '\033[31m',
        'green': '\033[32m',
        'yellow': '\033[33m',
        'blue': '\033[34m',
        'magenta': '\033[35m',
        'cyan': '\033[36m',
        'white': '\033[37m',
        'bright_black': '\033[90m',
        'bright_red': '\033[91m',
        'bright_green': '\033[92m',
        'bright_yellow': '\033[93m',
        'bright_blue': '\033[94m',
        'bright_magenta': '\033[95m',
        'bright_cyan': '\033[96m',
        'bright_white': '\033[97m',
        'reset': '\033[0m',
        'bold': '\033[1m',
        'dim': '\033[2m',
        'italic': '\033[3m',
        'underline': '\033[4m',
        'blink': '\033[5m',
        'reverse': '\033[7m'
    }
    
    def __init__(self, config):
        self.config = config
        self.current_theme = 'default'
        self.custom_themes = {}
        self.theme_file = os.path.join(config.get('cache_path', 'cache'), 'theme.json')
        self._load_theme()
    
    def _load_theme(self):
        """Load saved theme"""
        if os.path.exists(self.theme_file):
            try:
                with open(self.theme_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.current_theme = data.get('current', 'default')
                    self.custom_themes = data.get('custom', {})
            except:
                pass
    
    def _save_theme(self):
        """Save current theme"""
        try:
            os.makedirs(os.path.dirname(self.theme_file), exist_ok=True)
            with open(self.theme_file, 'w', encoding='utf-8') as f:
                json.dump({
                    'current': self.current_theme,
                    'custom': self.custom_themes
                }, f)
        except:
            pass
    
    def get_theme(self) -> Dict[str, str]:
        """Get current theme"""
        if self.current_theme in self.THEMES:
            return self.THEMES[self.current_theme]
        elif self.current_theme in self.custom_themes:
            return self.custom_themes[self.current_theme]
        return self.THEMES['default']
    
    def set_theme(self, theme_name: str) -> bool:
        """Set current theme"""
        if theme_name in self.THEMES or theme_name in self.custom_themes:
            self.current_theme = theme_name
            self._save_theme()
            return True
        return False
    
    def get_available_themes(self) -> Dict[str, str]:
        """Get list of available themes"""
        themes = {}
        for name, theme in self.THEMES.items():
            themes[name] = theme['name']
        for name, theme in self.custom_themes.items():
            themes[name] = theme.get('name', name)
        return themes
    
    def color(self, text: str, color_name: str, bold: bool = False) -> str:
        """Apply color to text"""
        theme = self.get_theme()
        
        # Get color from theme or direct color name
        actual_color = theme.get(color_name, color_name)
        
        code = self.ANSI_COLORS.get(actual_color, '')
        reset = self.ANSI_COLORS['reset']
        bold_code = self.ANSI_COLORS['bold'] if bold else ''
        
        return f"{bold_code}{code}{text}{reset}"
    
    def c(self, color_name: str) -> str:
        """Get color code shorthand"""
        theme = self.get_theme()
        actual_color = theme.get(color_name, color_name)
        return self.ANSI_COLORS.get(actual_color, '')
    
    def reset(self) -> str:
        """Get reset code"""
        return self.ANSI_COLORS['reset']
    
    def show_theme_preview(self, theme_name: str = None):
        """Show theme preview"""
        theme = self.THEMES.get(theme_name, self.get_theme())
        
        print(f"\n{self.ANSI_COLORS['bold']}Theme: {theme['name']}{self.ANSI_COLORS['reset']}\n")
        
        for key, color in theme.items():
            if key != 'name' and color in self.ANSI_COLORS:
                code = self.ANSI_COLORS[color]
                print(f"  {code}{key}: {color}{self.ANSI_COLORS['reset']}")
    
    def create_custom_theme(self, name: str, base_theme: str = 'default', **kwargs) -> bool:
        """Create custom theme based on existing"""
        if base_theme not in self.THEMES:
            return False
        
        new_theme = self.THEMES[base_theme].copy()
        new_theme['name'] = kwargs.get('display_name', name)
        new_theme.update(kwargs)
        
        self.custom_themes[name] = new_theme
        self._save_theme()
        return True
    
    def interactive_theme_menu(self):
        """Interactive theme selection menu"""
        print("\n" + "=" * 50)
        print("          THEME SELECTION")
        print("=" * 50 + "\n")
        
        themes = self.get_available_themes()
        
        for i, (key, name) in enumerate(themes.items(), 1):
            marker = " [*]" if key == self.current_theme else "    "
            theme = self.THEMES.get(key, self.custom_themes.get(key, {}))
            color = self.ANSI_COLORS.get(theme.get('primary', 'white'), '')
            reset = self.ANSI_COLORS['reset']
            print(f"  {color}[{i}]{reset} {name}{marker}")
        
        print(f"\n  [0] Back")
        print("\n" + "=" * 50)
        
        choice = input("\nSelect theme: ").strip()
        
        try:
            idx = int(choice)
            if idx == 0:
                return
            if 1 <= idx <= len(themes):
                theme_key = list(themes.keys())[idx - 1]
                self.set_theme(theme_key)
                print(f"\n[OK] Theme changed to: {themes[theme_key]}")
        except:
            print("\n[!] Invalid choice")