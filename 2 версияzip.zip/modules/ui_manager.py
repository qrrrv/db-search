# -*- coding: utf-8 -*-
"""
User Interface Manager v2.5
Beautiful console UI with themes and animations
"""
import os
import sys
import time
from typing import List, Dict, Any, Optional
# Try to import libraries for beautiful interface
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.box import ROUNDED, DOUBLE, HEAVY
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich import print as rprint
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False
try:
    from colorama import init, Fore, Back, Style as ColoramaStyle
    init(autoreset=True)
    COLORAMA_AVAILABLE = True
except ImportError:
    COLORAMA_AVAILABLE = False
try:
    from pyfiglet import Figlet
    PYFIGLET_AVAILABLE = True
except ImportError:
    PYFIGLET_AVAILABLE = False
try:
    from tabulate import tabulate
    TABULATE_AVAILABLE = True
except ImportError:
    TABULATE_AVAILABLE = False
try:
    from prompt_toolkit import prompt
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.history import FileHistory
    PROMPT_TOOLKIT_AVAILABLE = True
except ImportError:
    PROMPT_TOOLKIT_AVAILABLE = False
class UIManager:
    """Beautiful console interface manager with theme support"""
    
    VERSION = "2.5"
    
    def __init__(self, config, theme_manager=None):
        self.config = config
        self.theme_manager = theme_manager
        
        if RICH_AVAILABLE:
            self.console = Console()
        else:
            self.console = None
        
        # Setup prompt history
        self.history_file = os.path.join(config.get('cache_path', 'cache'), 'search_history.txt')
    
    def _c(self, color_name: str) -> str:
        """Get color code from theme"""
        if self.theme_manager:
            return self.theme_manager.c(color_name)
        return ''
    
    def _reset(self) -> str:
        """Get reset code"""
        if self.theme_manager:
            return self.theme_manager.reset()
        return '\033[0m'
    
    def clear_screen(self):
        """Clear screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def show_banner(self):
        """Show beautiful banner with theme colors"""
        theme = self.theme_manager.get_theme() if self.theme_manager else {}
        
        if PYFIGLET_AVAILABLE and RICH_AVAILABLE:
            try:
                fig = Figlet(font='slant')
                banner_text = fig.renderText('DB SEARCH')
                style = theme.get('banner_style', 'bold cyan')
                self.console.print(Panel(
                    Text(banner_text, style=style),
                    border_style=theme.get('border', 'blue'),
                    box=DOUBLE,
                    title=f"[bold yellow]v{self.VERSION} ULTIMATE[/bold yellow]",
                    subtitle=f"[dim]Theme: {theme.get('name', 'Default')}[/dim]"
                ))
            except:
                self._print_simple_banner()
        elif RICH_AVAILABLE:
            style = theme.get('menu_style', 'cyan')
            self.console.print(Panel(
                f"[bold {style}]========================================\n"
                f"       DATABASE SEARCH TOOL v{self.VERSION}\n"
                f"        Search in TXT/CSV databases\n"
                f"========================================[/bold {style}]",
                border_style=theme.get('border', 'blue')
            ))
        else:
            self._print_simple_banner()
    
    def _print_simple_banner(self):
        """Simple banner without libraries"""
        c = self._c('primary')
        r = self._reset()
        print(f"""
{c}================================================================
          DATABASE SEARCH TOOL v{self.VERSION} ULTIMATE
          Search in TXT/CSV databases
          Optimized for large files (20-70 GB)
================================================================{r}
""")
    
    def show_menu(self):
        """Show main menu with theme"""
        theme = self.theme_manager.get_theme() if self.theme_manager else {}
        
        if RICH_AVAILABLE:
            style = theme.get('menu_style', 'cyan')
            accent = theme.get('accent', 'yellow')
            success = theme.get('success', 'green')
            
            menu_content = f"""
[bold {style}]========================================
           [{accent}]MAIN MENU[/{accent}]
========================================
  [{success}][1][/{success}] Search in databases
  [{success}][2][/{success}] Index databases
  [{success}][3][/{success}] Statistics
  [{success}][4][/{success}] Settings
  [{success}][5][/{success}] Change theme
  [{success}][6][/{success}] Clear cache
  [{success}][7][/{success}] Database info
  [{success}][8][/{success}] Advanced search
  [red][0][/red] Exit
========================================[/bold {style}]
"""
            self.console.print(Panel(menu_content, border_style=theme.get('border', 'blue')))
        else:
            c = self._c('primary')
            g = self._c('success')
            y = self._c('accent')
            r = self._reset()
            print(f"""
{c}========================================
           {y}MAIN MENU{c}
========================================
  {g}[1]{c} Search in databases
  {g}[2]{c} Index databases
  {g}[3]{c} Statistics
  {g}[4]{c} Settings
  {g}[5]{c} Change theme
  {g}[6]{c} Clear cache
  {g}[7]{c} Database info
  {g}[8]{c} Advanced search
  {self._c('error')}[0]{c} Exit
========================================{r}
""")
    
    def get_user_choice(self) -> str:
        """Get user choice"""
        c = self._c('primary')
        r = self._reset()
        return input(f"{c}> Select action: {r}")
    
    def get_search_query(self) -> str:
        """Get search query with history"""
        if RICH_AVAILABLE:
            self.console.print("\n[bold yellow]Enter search query:[/bold yellow]")
            self.console.print("[dim](Telegram ID, phone, name, email, @username)[/dim]\n")
        else:
            y = self._c('accent')
            r = self._reset()
            print(f"\n{y}Enter search query:{r}")
            print(f"{self._c('dim')}(Telegram ID, phone, name, email, @username){r}\n")
        
        if PROMPT_TOOLKIT_AVAILABLE:
            try:
                os.makedirs(os.path.dirname(self.history_file), exist_ok=True)
                return prompt(
                    HTML('<green><b>Search: </b></green>'),
                    history=FileHistory(self.history_file)
                )
            except:
                pass
        
        return input(f"{self._c('success')}Search: {self._reset()}")
    
    def show_search_header(self):
        """Search header"""
        if RICH_AVAILABLE:
            theme = self.theme_manager.get_theme() if self.theme_manager else {}
            self.console.print(Panel(
                f"[bold {theme.get('primary', 'cyan')}]SEARCH IN DATABASES[/bold {theme.get('primary', 'cyan')}]",
                border_style=theme.get('border', 'cyan')
            ))
        else:
            c = self._c('primary')
            r = self._reset()
            print(f"\n{c}{'='*50}")
            print(f"       SEARCH IN DATABASES")
            print(f"{'='*50}{r}\n")
    
    def show_recent_searches(self, recent: List[Dict]):
        """Show recent searches"""
        if not recent:
            return
        
        if RICH_AVAILABLE:
            self.console.print("\n[dim]Recent searches:[/dim]")
            for i, item in enumerate(recent, 1):
                self.console.print(f"  [dim]{i}. {item['query']} ({item['results']} results)[/dim]")
            self.console.print()
        else:
            print(f"\n{self._c('dim')}Recent searches:{self._reset()}")
            for i, item in enumerate(recent, 1):
                print(f"  {i}. {item['query']} ({item['results']} results)")
            print()
    
    def show_query_analysis(self, parsed: Dict):
        """Show query type analysis"""
        if RICH_AVAILABLE:
            query_type = parsed.get('type', 'unknown')
            patterns = parsed.get('patterns', [])
            
            self.console.print(f"\n[cyan]Query type:[/cyan] [bold]{query_type}[/bold]")
            if patterns:
                self.console.print(f"[cyan]Detected patterns:[/cyan] {', '.join(patterns)}")
        else:
            print(f"\n{self._c('primary')}Query type: {parsed.get('type', 'unknown')}{self._reset()}")
    
    def show_progress_start(self):
        """Show progress start"""
        if RICH_AVAILABLE:
            self.console.print("\n[bold yellow]Searching...[/bold yellow]\n")
        else:
            print(f"\n{self._c('accent')}Searching...{self._reset()}\n")
    
    def show_results(self, results: List[Dict], search_stats: Dict = None):
        """Show search results with theme"""
        theme = self.theme_manager.get_theme() if self.theme_manager else {}
        
        if not results:
            if RICH_AVAILABLE:
                self.console.print(Panel(
                    "[bold red]Nothing found[/bold red]",
                    border_style="red"
                ))
            else:
                print(f"\n{self._c('error')}Nothing found{self._reset()}\n")
            return
        
        # Show stats
        if search_stats:
            if RICH_AVAILABLE:
                self.console.print(f"\n[bold green]Found: {len(results)} results[/bold green]")
                self.console.print(f"[dim]Files searched: {search_stats.get('files_searched', 0)} | "
                                  f"Lines scanned: {search_stats.get('lines_searched', 0):,}[/dim]\n")
            else:
                print(f"\n{self._c('success')}Found: {len(results)} results{self._reset()}")
        
        if RICH_AVAILABLE:
            table = Table(
                title="Search Results",
                box=ROUNDED,
                border_style=theme.get('border', 'cyan'),
                header_style=f"bold {theme.get('accent', 'magenta')}"
            )
            
            table.add_column("#", style="dim", width=4)
            table.add_column("File", style=theme.get('primary', 'cyan'), width=25)
            table.add_column("Line", style=theme.get('accent', 'yellow'), width=8)
            table.add_column("Data", style=theme.get('success', 'green'), max_width=50)
            
            for i, result in enumerate(results[:50], 1):
                parsed = result.get('parsed', {})
                data_parts = []
                
                for key in ['telegram_id', 'phone', 'email', 'username', 'name']:
                    if key in parsed:
                        data_parts.append(f"{key}: {parsed[key]}")
                
                data_str = " | ".join(data_parts) if data_parts else result.get('raw_data', '')[:50]
                
                table.add_row(
                    str(i),
                    result.get('file', 'N/A')[:25],
                    str(result.get('line_number', 'N/A')),
                    data_str
                )
            
            self.console.print(table)
            
            if len(results) > 50:
                self.console.print(f"\n[dim]... and {len(results) - 50} more results[/dim]")
        
        elif TABULATE_AVAILABLE:
            print(f"\n{self._c('success')}Found: {len(results)} results{self._reset()}\n")
            
            table_data = []
            for i, result in enumerate(results[:50], 1):
                table_data.append([
                    i,
                    result.get('file', 'N/A')[:25],
                    result.get('line_number', 'N/A'),
                    result.get('raw_data', '')[:50]
                ])
            
            print(tabulate(table_data, headers=['#', 'File', 'Line', 'Data'], tablefmt='grid'))
        else:
            self._show_results_simple(results)
    
    def _show_results_simple(self, results: List[Dict]):
        """Simple results display"""
        print(f"\n{self._c('success')}Found: {len(results)} results{self._reset()}\n")
        print("-" * 80)
        
        for i, result in enumerate(results[:50], 1):
            print(f"{self._c('primary')}[{i}]{self._reset()} {result.get('file', 'N/A')} "
                  f"(line {result.get('line_number', 'N/A')})")
            print(f"    {self._c('success')}{result.get('raw_data', '')[:70]}{self._reset()}")
            print("-" * 80)
    
    def show_indexing_header(self):
        """Indexing header"""
        if RICH_AVAILABLE:
            self.console.print(Panel(
                "[bold cyan]INDEXING DATABASES[/bold cyan]",
                border_style="cyan"
            ))
        else:
            print(f"\n{self._c('primary')}{'='*50}")
            print(f"       INDEXING DATABASES")
            print(f"{'='*50}{self._reset()}\n")
    
    def ask_export_format(self) -> Optional[str]:
        """Ask about export format"""
        if RICH_AVAILABLE:
            self.console.print("\n[yellow]Export results?[/yellow]")
            self.console.print("  [green][1][/green] TXT  [green][2][/green] CSV  [green][3][/green] JSON  [dim][0] Skip[/dim]")
        else:
            print(f"\n{self._c('accent')}Export results?{self._reset()}")
            print(f"  {self._c('success')}[1]{self._reset()} TXT  "
                  f"{self._c('success')}[2]{self._reset()} CSV  "
                  f"{self._c('success')}[3]{self._reset()} JSON  "
                  f"{self._c('dim')}[0] Skip{self._reset()}")
        
        choice = input("> ").strip()
        
        formats = {'1': 'txt', '2': 'csv', '3': 'json'}
        return formats.get(choice)
    
    def show_export_success(self, filepath: str):
        """Export success"""
        if RICH_AVAILABLE:
            self.console.print(f"\n[bold green]Results exported to:[/bold green] {filepath}")
        else:
            print(f"\n{self._c('success')}Results exported to: {filepath}{self._reset()}")
    
    def show_cache_stats(self, stats: Dict):
        """Show cache statistics"""
        if RICH_AVAILABLE:
            self.console.print(f"\n[cyan]Cache Statistics:[/cyan]")
            self.console.print(f"  Entries: {stats.get('entries', 0)}")
            self.console.print(f"  Hit rate: {stats.get('hit_rate', '0%')}")
            self.console.print(f"  Hits: {stats.get('hits', 0)} | Misses: {stats.get('misses', 0)}")
        else:
            print(f"\n{self._c('primary')}Cache Statistics:{self._reset()}")
            print(f"  Entries: {stats.get('entries', 0)}")
            print(f"  Hit rate: {stats.get('hit_rate', '0%')}")
    
    def show_cache_cleared(self):
        """Cache cleared"""
        if RICH_AVAILABLE:
            self.console.print("[bold green]Cache cleared successfully![/bold green]")
        else:
            print(f"{self._c('success')}Cache cleared!{self._reset()}")
    
    def show_invalid_choice(self):
        """Invalid choice"""
        if RICH_AVAILABLE:
            self.console.print("[bold red]Invalid choice. Try again.[/bold red]")
        else:
            print(f"{self._c('error')}Invalid choice{self._reset()}")
    
    def show_goodbye(self):
        """Goodbye"""
        if RICH_AVAILABLE:
            self.console.print(Panel(
                "[bold cyan]Goodbye! Thanks for using DB Search Tool[/bold cyan]",
                border_style="cyan"
            ))
        else:
            print(f"\n{self._c('primary')}Goodbye!{self._reset()}\n")
    
    def show_advanced_search_menu(self, advanced):
        """Show advanced search options"""
        print("\n" + "=" * 50)
        print("          ADVANCED SEARCH")
        print("=" * 50)
        print("\nAvailable patterns:")
        
        for i, (name, pattern) in enumerate(advanced.PATTERNS.items(), 1):
            print(f"  [{i}] {name}")
        
        print("\n  [0] Back")
        print("=" * 50)
    
    def wait_for_key(self):
        """Wait for key press"""
        print(f"\n{self._c('dim')}Press Enter to continue...{self._reset()}")
        input()
