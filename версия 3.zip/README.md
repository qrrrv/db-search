# Database Search Tool v2.0 PRO

Powerful and beautiful tool for searching information in large databases (TXT, CSV).
Optimized for files 20-70 GB in size.

## Features

- **15 Beautiful Themes** - Cyberpunk, Neon, Hacker, Ocean, and more
- **Parallel Search** - Uses all CPU cores
- **Large File Support** - Memory-mapped files for 20-70GB databases
- **Animated Interface** - Spinners, progress bars, ASCII art
- **Smart Caching** - Fast repeat searches
- **Multiple Export Formats** - TXT, CSV, JSON, HTML
- **Search Statistics** - Track your searches

## Screenshots

```
    ____  ____     _____ _____    _    ____   ____ _   _ 
   |  _ \| __ )   / ___|| ____|  / \  |  _ \ / ___| | | |
   | | | |  _ \   \___ \|  _|   / _ \ | |_) | |   | |_| |
   | |_| | |_) |   ___) | |___ / ___ \|  _ <| |___|  _  |
   |____/|____/   |____/|_____/_/   \_\_| \_\\____|_| |_|
                                                    
            === DATABASE SEARCH TOOL v2.0 ===
```

## Installation

### Requirements
- Python 3.8 or higher
- Windows 10/11

### Quick Start

1. **Install Python** (if not installed)
   - Download from https://www.python.org/downloads/
   - Check "Add Python to PATH" during installation

2. **Install dependencies**
   ```
   install.bat
   ```

3. **Add your databases**
   - Copy .txt and .csv files to `bd` folder

4. **Run the program**
   ```
   start.bat
   ```

## Available Themes

| Theme | Description |
|-------|-------------|
| `default` | Classic cyan theme |
| `hacker` | Matrix-style green |
| `ocean` | Blue ocean waves |
| `fire` | Red and yellow flames |
| `purple` | Purple dreams |
| `cyberpunk` | Cyberpunk 2077 style |
| `neon` | Bright neon lights |
| `sunset` | Warm sunset colors |
| `arctic` | Cold arctic white |
| `dracula` | Dark dracula theme |
| `retro` | 80s retro style |
| `forest` | Green forest |
| `galaxy` | Space galaxy |
| `minimal` | Clean minimal |
| `blood` | Blood moon red |
| `gold` | Luxury gold |

## Project Structure

```
DB-Search-Tool/
|-- main.py                       # Main program
|-- config.json                   # Settings (auto-created)
|
|-- modules/                      # Core modules
|   |-- __init__.py
|   |-- search_engine.py          # Search engine
|   |-- ui_manager.py             # UI controller
|   |-- config_manager.py         # Settings manager
|   |-- logger.py                 # Logging
|   |-- file_indexer.py           # File indexing
|   |-- result_exporter.py        # Export results
|   |-- stats_manager.py          # Statistics
|   |-- cache_manager.py          # Caching
|   |-- parallel_processor.py     # Parallel processing
|   |-- database_manager.py       # Database management
|   |
|   |-- themes/                   # Theme system
|   |   |-- __init__.py
|   |   |-- theme_manager.py      # Theme controller
|   |   |-- color_schemes.py      # Color palettes
|   |   |-- ascii_art.py          # ASCII art generator
|   |   |-- animations.py         # Animations & spinners
|   |
|   |-- ui/                       # UI components
|       |-- __init__.py
|       |-- menu.py               # Menu system
|       |-- tables.py             # Table renderer
|       |-- panels.py             # Panel renderer
|       |-- input_handler.py      # Input handling
|       |-- display.py            # Display controller
|
|-- bd/                           # Your databases here
|-- results/                      # Search results
|-- cache/                        # Cache files
|-- logs/                         # Log files
|
|-- start.bat                     # Run program
|-- install.bat                   # Install dependencies
|-- quick_search.bat              # Quick search
|-- run_theme_demo.bat            # Theme demo
|-- requirements.txt              # Dependencies
|-- README.md                     # This file
```

## Libraries Used

### UI & Console
1. **Rich** - Beautiful tables, panels, progress bars
2. **Colorama** - Windows color support
3. **Prompt Toolkit** - Enhanced input with history
4. **Blessed** - Terminal control

### ASCII Art & Animations
5. **Pyfiglet** - ASCII art banners
6. **ART** - More ASCII art fonts
7. **Halo** - Spinners
8. **Alive-Progress** - Animated progress bars
9. **TQDM** - Classic progress bars

### Other
10. **Tabulate** - Table formatting
11. **Click** - CLI framework

## Usage

### Main Menu

```
[1] Search in databases    - Find data by any criteria
[2] Index databases        - Pre-index for faster search
[3] Statistics             - View search history
[4] Settings               - Configure the tool
[5] Clear cache            - Free up cache space
[6] Database info          - View database details
[7] Change theme           - Customize appearance
[0] Exit                   - Close the program
```

### Search Examples

```
Search: 123456789          (Telegram ID)
Search: +79001234567       (Phone number)
Search: John Smith         (Full name)
Search: example@mail.com   (Email)
Search: @username          (Username)
```

### Supported Data Types

- Telegram ID (6-12 digits)
- Phone numbers (any format)
- Email addresses
- Usernames (@username)
- Names (First, Last, Patronymic)

## Configuration

Settings are stored in `config.json`:

```json
{
    "database_path": "bd",
    "results_path": "results",
    "max_workers": null,
    "cache_enabled": true,
    "cache_ttl": 3600,
    "theme": "default",
    "export_format": "txt",
    "max_results_per_file": 1000,
    "max_total_results": 10000
}
```

## Performance Tips

1. **Use SSD** - Much faster file reading
2. **Index databases** - Run indexing first (option 2)
3. **Enable cache** - Faster repeat searches
4. **Increase workers** - For more CPU cores

## Troubleshooting

### "Python not found"
Install Python from python.org and check "Add to PATH"

### "Module not found"
Run `install.bat` to install all dependencies

### "No databases found"
Put your .txt and .csv files in the `bd` folder

### Encoding errors
The tool supports UTF-8, CP1251, Latin-1, CP866

---

**Version:** 2.0 PRO  
**License:** MIT